# 🚀 Guía de Despliegue - SCM Fast Delivery

## Opciones de Hosting

### 1. **Vercel (Recomendado)**
```bash
# Instalar Vercel CLI
npm i -g vercel

# Desplegar
vercel

# Desplegar en producción
vercel --prod
```

**Ventajas:**
- ✅ Optimizado para Next.js
- ✅ SSL automático
- ✅ CDN global
- ✅ Serverless functions
- ✅ Base de datos integrada (Vercel Postgres/SQLite)
- ✅ Dominio personalizado
- 💰 Gratis para proyectos pequeños

### 2. **Netlify**
```bash
# Build
npm run build

# Subir carpeta .next a Netlify
```

### 3. **AWS Amplify**
- Hosting estático + serverless
- Base de datos DynamoDB
- Autenticación Cognito

### 4. **DigitalOcean App Platform**
- $5/mes básico
- Base de datos PostgreSQL
- Fácil configuración

---

## 📱 Apps Móviles Nativas

### Opción A: React Native
```bash
# Crear app móvil
npx react-native init SCMDeliveryApp

# Usar misma API del backend
```

### Opción B: Expo (Más fácil)
```bash
# Crear proyecto Expo
npx create-expo-app delivery-app

# Publicar en App Store/Google Play
expo build:android
expo build:ios
```

### Opción C: PWA (Progressive Web App)
```javascript
// next.config.js
const withPWA = require('next-pwa')({
  dest: 'public'
})

module.exports = withPWA({
  // configuración existente
})
```

---

## 🔄 Integración con WordPress

### Método 1: Iframe Embed
```html
<!-- En WordPress -->
<iframe 
  src="https://tu-app.vercel.app/customer-platform" 
  width="100%" 
  height="800px"
  frameborder="0">
</iframe>
```

### Método 2: WordPress REST API Integration
```php
// functions.php en WordPress
function scm_delivery_products() {
    $response = wp_remote_get('https://tu-api.com/api/products');
    $products = json_decode(wp_remote_retrieve_body($response));
    
    return $products;
}
add_shortcode('scm_products', 'scm_delivery_products');
```

### Método 3: Plugin WordPress Personalizado
```php
// Plugin structure
/scm-delivery-plugin/
├── scm-delivery.php
├── admin/
│   └── settings.php
├── public/
│   └── frontend.php
└── assets/
    └── css/style.css
```

---

## 🗄️ Opciones de Base de Datos

### 1. **Vercel Postgres (Recomendado)**
```javascript
// lib/db.ts
import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const db = globalForPrisma.prisma ?? new PrismaClient()
```

### 2. **Supabase**
- Gratis hasta 500MB
- Real-time subscriptions
- Autenticación incluida

### 3. **PlanetScale**
- MySQL serverless
- Escalabilidad automática
- Branching de base de datos

### 4. **Railway**
- $5/mes PostgreSQL
- Fácil configuración

---

## 📊 Arquitectura de Producción

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Cliente Web   │    │   App Móvil     │    │   WordPress     │
│  (Next.js)      │    │  (React Native) │    │   (Plugin)      │
└─────────┬───────┘    └─────────┬───────┘    └─────────┬───────┘
          │                      │                      │
          └──────────────────────┼──────────────────────┘
                                 │
                    ┌─────────────▼─────────────┐
                    │      API Backend          │
                    │    (Next.js API Routes)   │
                    └─────────────┬─────────────┘
                                 │
                    ┌─────────────▼─────────────┐
                    │     Base de Datos         │
                    │   (PostgreSQL/SQLite)     │
                    └───────────────────────────┘
```

---

## 🔧 Configuración de Producción

### Variables de Entorno
```bash
# .env.production
DATABASE_URL="postgresql://user:pass@host:5432/db"
NEXTAUTH_SECRET="your-secret-key"
NEXTAUTH_URL="https://yourdomain.com"
GOOGLE_PLACES_API_KEY="your-google-api-key"
```

### Docker para Hosting Propio
```dockerfile
# Dockerfile
FROM node:18-alpine

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

EXPOSE 3000
CMD ["npm", "start"]
```

### docker-compose.yml
```yaml
version: '3.8'
services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - DATABASE_URL=postgresql://user:pass@db:5432/scm
    depends_on:
      - db
  
  db:
    image: postgres:15
    environment:
      POSTGRES_DB: scm
      POSTGRES_USER: user
      POSTGRES_PASSWORD: pass
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  postgres_data:
```

---

## 💰 Costos Estimados Mensuales

### Opción Económica (Gratis - $20/mes)
- **Vercel Pro**: $20/mes
- **Vercel Postgres**: $0/mes (hasta 512MB)
- **Google Places API**: $0/mes (hasta 2,800 peticiones)
- **Total**: ~$20/mes

### Opción Profesional ($50 - $100/mes)
- **Vercel Pro**: $20/mes
- **Base de datos dedicada**: $20/mes
- **Dominio personalizado**: $12/año
- **APIs adicionales**: $20/mes
- **Total**: ~$60/mes

### Opción Enterprise ($200+/mes)
- **Servidor dedicado**: $100/mes
- **Base de datos enterprise**: $50/mes
- **CDN avanzado**: $30/mes
- **Soporte 24/7**: $50/mes
- **Total**: ~$230/mes

---

## 🚀 Pasos para Poner en Producción

### 1. Preparar el Proyecto
```bash
# Actualizar dependencias
npm update

# Build de producción
npm run build

# Probar localmente
npm start
```

### 2. Configurar Base de Datos
```bash
# Migrar schema
npx prisma migrate deploy

# Generar Prisma Client
npx prisma generate
```

### 3. Desplegar en Vercel
```bash
# Instalar CLI
npm i -g vercel

# Conectar proyecto
vercel link

# Desplegar
vercel --prod
```

### 4. Configurar Dominio
```bash
# En Vercel dashboard
# 1. Ir a Settings > Domains
# 2. Agregar tu-dominio.com
# 3. Configurar DNS según instrucciones
```

### 5. Monitoreo
```javascript
// lib/monitoring.ts
export function logError(error: Error) {
  console.error('Production Error:', error)
  // Enviar a servicio de monitoreo
}

export function logAnalytics(event: string) {
  // Enviar a Google Analytics
}
```

---

## 📱 Estrategia Móvil

### Opción 1: PWA (Recomendado para empezar)
- **Costo**: $0
- **Tiempo**: 1 día
- **Funcionalidad**: 90%
- **Instalable**: ✅
- **Offline**: ✅

### Opción 2: React Native
- **Costo**: $5,000 - $15,000
- **Tiempo**: 2-3 meses
- **Funcionalidad**: 100%
- **App Store**: ✅
- **Google Play**: ✅

### Opción 3: Flutter
- **Costo**: $5,000 - $15,000
- **Tiempo**: 2-3 meses
- **Funcionalidad**: 100%
- **Multiplataforma**: ✅

---

## 🔗 Integración con Sistemas Existentes

### API Rest para Terceros
```javascript
// api/external/v1/route.ts
export async function GET(request: Request) {
  // Autenticación con API Key
  const apiKey = request.headers.get('x-api-key')
  
  if (!isValidApiKey(apiKey)) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 })
  }
  
  // Retornar datos públicos
  return Response.json({
    products: await getPublicProducts(),
    categories: await getPublicCategories()
  })
}
```

### Webhooks para Notificaciones
```javascript
// api/webhooks/delivery-update/route.ts
export async function POST(request: Request) {
  const update = await request.json()
  
  // Procesar actualización
  await processDeliveryUpdate(update)
  
  // Notificar a sistemas externos
  await notifyExternalSystems(update)
  
  return Response.json({ success: true })
}
```

---

## 🛡️ Seguridad en Producción

### 1. **Variables de Entorno**
```bash
# Nunca exponer datos sensibles
NEXTAUTH_SECRET="super-secret-key"
DATABASE_URL="private-connection-string"
```

### 2. **CORS Configuration**
```javascript
// next.config.js
module.exports = {
  async headers() {
    return [
      {
        source: '/api/:path*',
        headers: [
          { key: 'Access-Control-Allow-Origin', value: 'https://tu-dominio.com' },
          { key: 'Access-Control-Allow-Methods', value: 'GET,OPTIONS,PATCH,DELETE,POST,PUT' }
        ]
      }
    ]
  }
}
```

### 3. **Rate Limiting**
```javascript
// middleware.ts
import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

export function middleware(request: NextRequest) {
  // Implementar rate limiting
  const ip = request.ip || 'unknown'
  
  // Lógica de rate limiting aquí
  
  return NextResponse.next()
}
```

---

## 📈 Monitoreo y Analytics

### 1. **Google Analytics 4**
```javascript
// components/Analytics.tsx
import Script from 'next/script'

export default function Analytics() {
  return (
    <>
      <Script
        src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"
        strategy="afterInteractive"
      />
      <Script id="google-analytics" strategy="afterInteractive">
        {`
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
          gtag('config', 'GA_MEASUREMENT_ID');
        `}
      </Script>
    </>
  )
}
```

### 2. **Sentry para Error Tracking**
```javascript
// lib/sentry.ts
import * as Sentry from "@sentry/nextjs";

Sentry.init({
  dsn: "YOUR_SENTRY_DSN",
  environment: process.env.NODE_ENV,
});
```

---

## 🎯 Recomendación Final

### Para empezar rápido:
1. **Vercel** para hosting
2. **PWA** para versión móvil
3. **Vercel Postgres** para base de datos
4. **Iframe** para integración WordPress

### Para escalar:
1. **React Native** para apps nativas
2. **WordPress Plugin** personalizado
3. **API externa** para integraciones
4. **Servidor dedicado** para alto tráfico

La arquitectura está diseñada para crecer gradualmente según tus necesidades y presupuesto.