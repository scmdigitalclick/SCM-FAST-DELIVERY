<?php
/*
Plugin Name: SCM Fast Delivery Integration
Description: Integra SCM Fast Delivery con WordPress
Version: 1.0
Author: Tu Nombre
*/

// Evitar acceso directo
if (!defined('ABSPATH')) {
    exit;
}

// ==================== SHORTCODES ====================

// Mostrar catálogo de productos
add_shortcode('scm_catalog', 'scm_show_catalog');
function scm_show_catalog() {
    $api_url = 'https://tu-app.vercel.app/api/products';
    $response = wp_remote_get($api_url);
    
    if (is_wp_error($response)) {
        return '<p>Error cargando catálogo</p>';
    }
    
    $products = json_decode(wp_remote_retrieve_body($response));
    
    ob_start();
    ?>
    <div class="scm-catalog">
        <h2>Nuestros Productos</h2>
        <div class="scm-products-grid">
            <?php foreach ($products as $product): ?>
                <div class="scm-product-card">
                    <h3><?php echo esc_html($product->name); ?></h3>
                    <p><?php echo esc_html($product->description); ?></p>
                    <p class="price">$<?php echo number_format($product->price, 2); ?></p>
                    <button class="scm-order-btn" 
                            data-product-id="<?php echo $product->id; ?>"
                            data-product-name="<?php echo esc_html($product->name); ?>"
                            data-product-price="<?php echo $product->price; ?>">
                        Ordenar
                    </button>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <!-- Modal de pedido -->
    <div id="scm-order-modal" style="display:none;">
        <div class="scm-modal-content">
            <h3>Realizar Pedido</h3>
            <form id="scm-order-form">
                <input type="hidden" id="product-id" name="product_id">
                <input type="hidden" id="product-name" name="product_name">
                <input type="hidden" id="product-price" name="product_price">
                
                <label>Nombre Completo:</label>
                <input type="text" name="customer_name" required>
                
                <label>Teléfono:</label>
                <input type="tel" name="customer_phone" required>
                
                <label>Dirección:</label>
                <textarea name="customer_address" required></textarea>
                
                <label>Cantidad:</label>
                <input type="number" name="quantity" value="1" min="1" required>
                
                <button type="submit">Confirmar Pedido</button>
                <button type="button" onclick="closeOrderModal()">Cancelar</button>
            </form>
        </div>
    </div>
    
    <style>
    .scm-catalog { max-width: 1200px; margin: 0 auto; }
    .scm-products-grid { 
        display: grid; 
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); 
        gap: 20px; 
        margin-top: 20px;
    }
    .scm-product-card { 
        border: 1px solid #ddd; 
        padding: 20px; 
        border-radius: 8px; 
        text-align: center;
    }
    .scm-product-card .price { 
        font-size: 1.5em; 
        font-weight: bold; 
        color: #007cba;
        margin: 10px 0;
    }
    .scm-order-btn { 
        background: #007cba; 
        color: white; 
        border: none; 
        padding: 10px 20px; 
        border-radius: 5px; 
        cursor: pointer;
    }
    .scm-order-btn:hover { background: #005a87; }
    
    /* Modal */
    #scm-order-modal {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        z-index: 1000;
    }
    .scm-modal-content {
        background: white;
        max-width: 500px;
        margin: 50px auto;
        padding: 30px;
        border-radius: 10px;
    }
    .scm-modal-content form {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }
    .scm-modal-content input,
    .scm-modal-content textarea {
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 5px;
    }
    .scm-modal-content button {
        padding: 12px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    .scm-modal-content button[type="submit"] {
        background: #28a745;
        color: white;
    }
    .scm-modal-content button[type="button"] {
        background: #6c757d;
        color: white;
    }
    </style>
    
    <script>
    function closeOrderModal() {
        document.getElementById('scm-order-modal').style.display = 'none';
    }
    
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('scm-order-btn')) {
            document.getElementById('product-id').value = e.target.dataset.productId;
            document.getElementById('product-name').value = e.target.dataset.productName;
            document.getElementById('product-price').value = e.target.dataset.productPrice;
            document.getElementById('scm-order-modal').style.display = 'block';
        }
    });
    
    document.getElementById('scm-order-form').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const orderData = {
            customerName: formData.get('customer_name'),
            customerPhone: formData.get('customer_phone'),
            customerAddress: formData.get('customer_address'),
            productId: formData.get('product_id'),
            quantity: formData.get('quantity'),
            total: formData.get('product_price') * formData.get('quantity')
        };
        
        // Enviar pedido a la API
        fetch('https://tu-app.vercel.app/api/orders', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(orderData)
        })
        .then(response => response.json())
        .then(data => {
            alert('¡Pedido realizado con éxito!');
            closeOrderModal();
            this.reset();
        })
        .catch(error => {
            alert('Error al realizar el pedido');
            console.error('Error:', error);
        });
    });
    </script>
    <?php
    return ob_get_clean();
}

// Mostrar estado de entregas
add_shortcode('scm_tracking', 'scm_show_tracking');
function scm_show_tracking() {
    ?>
    <div class="scm-tracking">
        <h2>Seguimiento de Entregas</h2>
        <div class="scm-tracking-form">
            <input type="text" id="tracking-phone" placeholder="Ingresa tu teléfono">
            <button onclick="checkOrderStatus()">Buscar Pedido</button>
        </div>
        <div id="tracking-result"></div>
    </div>
    
    <style>
    .scm-tracking { max-width: 600px; margin: 0 auto; }
    .scm-tracking-form { 
        display: flex; 
        gap: 10px; 
        margin: 20px 0;
    }
    .scm-tracking-form input { 
        flex: 1; 
        padding: 10px; 
        border: 1px solid #ddd; 
        border-radius: 5px;
    }
    .scm-tracking-form button { 
        padding: 10px 20px; 
        background: #007cba; 
        color: white; 
        border: none; 
        border-radius: 5px; 
        cursor: pointer;
    }
    #tracking-result { margin-top: 20px; }
    </style>
    
    <script>
    function checkOrderStatus() {
        const phone = document.getElementById('tracking-phone').value;
        
        fetch(`https://tu-app.vercel.app/api/deliveries?phone=${phone}`)
        .then(response => response.json())
        .then(deliveries => {
            const resultDiv = document.getElementById('tracking-result');
            
            if (deliveries.length === 0) {
                resultDiv.innerHTML = '<p>No se encontraron pedidos para este teléfono.</p>';
                return;
            }
            
            let html = '<h3>Tus Pedidos:</h3>';
            deliveries.forEach(delivery => {
                html += `
                    <div class="delivery-card">
                        <p><strong>Pedido:</strong> ${delivery.id}</p>
                        <p><strong>Estado:</strong> ${delivery.status}</p>
                        <p><strong>Dirección:</strong> ${delivery.customerAddress}</p>
                        <p><strong>Total:</strong> $${delivery.total}</p>
                    </div>
                `;
            });
            
            resultDiv.innerHTML = html;
        })
        .catch(error => {
            document.getElementById('tracking-result').innerHTML = 
                '<p>Error al buscar pedidos. Inténtalo de nuevo.</p>';
        });
    }
    </script>
    <?php
}

// ==================== PÁGINA DE CONFIGURACIÓN ====================

add_action('admin_menu', 'scm_admin_menu');
function scm_admin_menu() {
    add_options_page(
        'SCM Delivery Settings',
        'SCM Delivery',
        'manage_options',
        'scm-delivery',
        'scm_settings_page'
    );
}

function scm_settings_page() {
    ?>
    <div class="wrap">
        <h1>SCM Fast Delivery Settings</h1>
        
        <form method="post" action="options.php">
            <?php
            settings_fields('scm_settings');
            do_settings_sections('scm_settings');
            ?>
            
            <table class="form-table">
                <tr>
                    <th scope="row">API URL</th>
                    <td>
                        <input type="text" 
                               name="scm_api_url" 
                               value="<?php echo esc_attr(get_option('scm_api_url')); ?>"
                               class="regular-text"
                               placeholder="https://tu-app.vercel.app">
                        <p class="description">URL de tu aplicación SCM Fast Delivery</p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">API Key</th>
                    <td>
                        <input type="text" 
                               name="scm_api_key" 
                               value="<?php echo esc_attr(get_option('scm_api_key')); ?>"
                               class="regular-text"
                               placeholder="tu-api-key">
                        <p class="description">Clave de API para autenticación (opcional)</p>
                    </td>
                </tr>
                
                <tr>
                    <th scope="row">Mostrar Catálogo</th>
                    <td>
                        <select name="scm_show_catalog">
                            <option value="yes" <?php selected(get_option('scm_show_catalog'), 'yes'); ?>>Sí</option>
                            <option value="no" <?php selected(get_option('scm_show_catalog'), 'no'); ?>>No</option>
                        </select>
                    </td>
                </tr>
            </table>
            
            <?php submit_button(); ?>
        </form>
        
        <h2>Shortcodes Disponibles</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Shortcode</th>
                    <th>Descripción</th>
                    <th>Ejemplo</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><code>[scm_catalog]</code></td>
                    <td>Muestra el catálogo de productos</td>
                    <td>Añadir a cualquier página o post</td>
                </tr>
                <tr>
                    <td><code>[scm_tracking]</code></td>
                    <td>Formulario de seguimiento de pedidos</td>
                    <td>Perfecto para página de "Seguimiento"</td>
                </tr>
            </tbody>
        </table>
        
        <h2>Link a Plataforma Completa</h2>
        <p>También puedes enlazar directamente a las plataformas completas:</p>
        <ul>
            <li><strong>Clientes:</strong> <a href="<?php echo esc_attr(get_option('scm_api_url')); ?>/customer-platform" target="_blank"><?php echo esc_html(get_option('scm_api_url')); ?>/customer-platform</a></li>
            <li><strong>Repartidores:</strong> <a href="<?php echo esc_attr(get_option('scm_api_url')); ?>/delivery-app" target="_blank"><?php echo esc_html(get_option('scm_api_url')); ?>/delivery-app</a></li>
        </ul>
    </div>
    <?php
}

// Registrar configuración
add_action('admin_init', 'scm_settings_init');
function scm_settings_init() {
    register_setting('scm_settings', 'scm_api_url');
    register_setting('scm_settings', 'scm_api_key');
    register_setting('scm_settings', 'scm_show_catalog');
}

// ==================== WIDGET ====================

class SCM_Delivery_Widget extends WP_Widget {
    public function __construct() {
        parent::__construct(
            'scm_delivery_widget',
            'SCM Delivery - Catálogo',
            array('description' => 'Muestra productos de SCM Fast Delivery')
        );
    }
    
    public function widget($args, $instance) {
        echo $args['before_widget'];
        
        if (!empty($instance['title'])) {
            echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];
        }
        
        // Mostrar productos destacados
        $api_url = get_option('scm_api_url') . '/api/products?limit=3';
        $response = wp_remote_get($api_url);
        
        if (!is_wp_error($response)) {
            $products = json_decode(wp_remote_retrieve_body($response));
            
            echo '<div class="scm-widget-products">';
            foreach ($products as $product) {
                echo '<div class="scm-widget-product">';
                echo '<h4>' . esc_html($product->name) . '</h4>';
                echo '<p class="price">$' . number_format($product->price, 2) . '</p>';
                echo '<a href="' . get_option('scm_api_url') . '/customer-platform" class="button">Ordenar</a>';
                echo '</div>';
            }
            echo '</div>';
            
            echo '<p><a href="' . get_option('scm_api_url') . '/customer-platform" class="button">Ver Catálogo Completo</a></p>';
        }
        
        echo $args['after_widget'];
    }
    
    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : 'Nuestros Productos';
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">Título:</label>
            <input class="widefat" 
                   id="<?php echo $this->get_field_id('title'); ?>" 
                   name="<?php echo $this->get_field_name('title'); ?>" 
                   type="text" 
                   value="<?php echo esc_attr($title); ?>">
        </p>
        <?php
    }
    
    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? sanitize_text_field($new_instance['title']) : '';
        return $instance;
    }
}

add_action('widgets_init', function() {
    register_widget('SCM_Delivery_Widget');
});

?>