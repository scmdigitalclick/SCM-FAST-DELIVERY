'use client'

import { useEffect, useState } from 'react'
import dynamic from 'next/dynamic'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Truck, Package, MapPin, Navigation, RefreshCw, Wifi, WifiOff } from 'lucide-react'
import { useRealTimeLocations } from '@/hooks/useRealTimeLocations'

// Importar Leaflet dinámicamente para evitar SSR issues
const MapContainer = dynamic(
  () => import('react-leaflet').then((mod) => mod.MapContainer),
  { ssr: false }
)

const TileLayer = dynamic(
  () => import('react-leaflet').then((mod) => mod.TileLayer),
  { ssr: false }
)

const Marker = dynamic(
  () => import('react-leaflet').then((mod) => mod.Marker),
  { ssr: false }
)

const Popup = dynamic(
  () => import('react-leaflet').then((mod) => mod.Popup),
  { ssr: false }
)

interface DeliveryPerson {
  id: string
  name: string
  phone: string
  isAvailable: boolean
  activeDeliveries: number
}

interface Delivery {
  id: string
  customerName: string
  customerAddress: string
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED'
  deliveryPerson?: {
    name: string
    phone: string
  }
  estimatedTime: string
  items: number
  total: number
}

interface DeliveryMapProps {
  deliveryPersons: DeliveryPerson[]
  deliveries: Delivery[]
  onRefresh?: () => void
}

export default function DeliveryMap({ deliveryPersons, deliveries, onRefresh }: DeliveryMapProps) {
  const [mapReady, setMapReady] = useState(false)
  const [selectedDelivery, setSelectedDelivery] = useState<string | null>(null)
  const [selectedPerson, setSelectedPerson] = useState<string | null>(null)
  const [L, setL] = useState<any>(null)
  
  const {
    deliveryPersons: deliveryPersonsWithLocation,
    deliveries: deliveriesWithLocation,
    isConnected,
    updateDeliveryPersons,
    updateDeliveries
  } = useRealTimeLocations()

  // Actualizar datos cuando cambian las props
  useEffect(() => {
    updateDeliveryPersons(deliveryPersons)
    updateDeliveries(deliveries)
  }, [deliveryPersons, deliveries, updateDeliveryPersons, updateDeliveries])

  // Ubicación central (puedes cambiarla a tu ubicación principal)
  const centerPosition = [19.4326, -99.1332] // Ciudad de México

  useEffect(() => {
    // Cargar Leaflet solo en el cliente
    if (typeof window !== 'undefined') {
      import('leaflet').then((leaflet) => {
        // Fix para los iconos de Leaflet
        delete (leaflet.Icon.Default.prototype as any)._getIconUrl
        leaflet.Icon.Default.mergeOptions({
          iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
          iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
          shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
        })
        setL(leaflet)
        setMapReady(true)
      })
    }
  }, [])

  const createCustomIcon = (type: 'delivery' | 'person', status?: string) => {
    if (!L) return null

    const getDeliveryColor = (status?: string) => {
      switch (status) {
        case 'PENDING': return 'bg-yellow-500'
        case 'IN_PROGRESS': return 'bg-blue-500'
        case 'COMPLETED': return 'bg-green-500'
        case 'CANCELLED': return 'bg-red-500'
        default: return 'bg-blue-500'
      }
    }

    const getPersonColor = (isAvailable: boolean) => {
      return isAvailable ? 'bg-green-500' : 'bg-red-500'
    }

    const color = type === 'delivery' ? getDeliveryColor(status) : getPersonColor(true)

    if (type === 'delivery') {
      return L.divIcon({
        html: `
          <div class="flex items-center justify-center w-8 h-8 ${color} rounded-full border-2 border-white shadow-lg animate-pulse">
            <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path>
            </svg>
          </div>
        `,
        className: 'custom-marker',
        iconSize: [32, 32],
        iconAnchor: [16, 16]
      })
    } else {
      return L.divIcon({
        html: `
          <div class="flex items-center justify-center w-8 h-8 ${color} rounded-full border-2 border-white shadow-lg">
            <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10a1 1 0 001 1h1m8-1a1 1 0 01-1 1H9m4-1V8a1 1 0 011-1h2.586a1 1 0 01.707.293l3.414 3.414a1 1 0 01.293.707V16a1 1 0 01-1 1h-1m-6-1a1 1 0 001 1h1M5 17a2 2 0 104 0m-4 0a2 2 0 114 0m6 0a2 2 0 104 0m-4 0a2 2 0 114 0"></path>
            </svg>
          </div>
        `,
        className: 'custom-marker',
        iconSize: [32, 32],
        iconAnchor: [16, 16]
      })
    }
  }

  if (!mapReady || !L) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="w-5 h-5" />
            Mapa de Entregas
          </CardTitle>
          <CardDescription>Cargando mapa...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="bg-gray-100 rounded-lg h-96 flex items-center justify-center">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
              <p className="text-gray-600">Cargando mapa interactivo...</p>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                Mapa de Entregas SCM Fast Delivery
              </CardTitle>
              <CardDescription>
                Seguimiento en vivo de repartidores y entregas SCM
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1">
                {isConnected ? (
                  <>
                    <Wifi className="w-4 h-4 text-green-500" />
                    <span className="text-sm text-green-600">Conectado</span>
                  </>
                ) : (
                  <>
                    <WifiOff className="w-4 h-4 text-red-500" />
                    <span className="text-sm text-red-600">Desconectado</span>
                  </>
                )}
              </div>
              <Button variant="outline" size="sm" onClick={onRefresh}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Actualizar
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-lg overflow-hidden border" style={{ height: '500px' }}>
            <MapContainer
              center={centerPosition}
              zoom={13}
              style={{ height: '100%', width: '100%' }}
            >
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              
              {/* Marcadores de Repartidores */}
              {deliveryPersonsWithLocation.map((person) => (
                person.location && (
                  <Marker
                    key={person.id}
                    position={[person.location.lat, person.location.lng]}
                    icon={createCustomIcon('person')}
                    eventHandlers={{
                      click: () => setSelectedPerson(person.id)
                    }}
                  >
                    <Popup>
                      <div className="p-2 min-w-48">
                        <div className="flex items-center gap-2 mb-2">
                          <Truck className="w-4 h-4 text-green-600" />
                          <h4 className="font-semibold">{person.name}</h4>
                        </div>
                        <div className="space-y-1 text-sm">
                          <p className="flex items-center gap-2">
                            <span className="text-gray-600">Teléfono:</span>
                            <span>{person.phone}</span>
                          </p>
                          <p className="flex items-center gap-2">
                            <span className="text-gray-600">Estado:</span>
                            <Badge className={person.isAvailable ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                              {person.isAvailable ? 'Disponible' : 'Ocupado'}
                            </Badge>
                          </p>
                          <p className="flex items-center gap-2">
                            <span className="text-gray-600">Entregas activas:</span>
                            <span>{person.activeDeliveries}</span>
                          </p>
                          <p className="flex items-center gap-2">
                            <Navigation className="w-3 h-3 text-blue-500" />
                            <span className="text-xs text-blue-600">Última actualización: Ahora</span>
                          </p>
                        </div>
                      </div>
                    </Popup>
                  </Marker>
                )
              ))}
              
              {/* Marcadores de Entregas */}
              {deliveriesWithLocation.map((delivery) => (
                delivery.location && (
                  <Marker
                    key={delivery.id}
                    position={[delivery.location.lat, delivery.location.lng]}
                    icon={createCustomIcon('delivery', delivery.status)}
                    eventHandlers={{
                      click: () => setSelectedDelivery(delivery.id)
                    }}
                  >
                    <Popup>
                      <div className="p-2 min-w-48">
                        <div className="flex items-center gap-2 mb-2">
                          <Package className="w-4 h-4 text-blue-600" />
                          <h4 className="font-semibold">Entrega</h4>
                        </div>
                        <div className="space-y-1 text-sm">
                          <p className="flex items-center gap-2">
                            <span className="text-gray-600">Cliente:</span>
                            <span>{delivery.customerName}</span>
                          </p>
                          <p className="flex items-center gap-2">
                            <span className="text-gray-600">Dirección:</span>
                            <span className="text-xs">{delivery.customerAddress}</span>
                          </p>
                          <p className="flex items-center gap-2">
                            <span className="text-gray-600">Estado:</span>
                            <Badge className={
                              delivery.status === 'PENDING' ? 'bg-yellow-100 text-yellow-800' :
                              delivery.status === 'IN_PROGRESS' ? 'bg-blue-100 text-blue-800' :
                              delivery.status === 'COMPLETED' ? 'bg-green-100 text-green-800' :
                              'bg-red-100 text-red-800'
                            }>
                              {delivery.status === 'PENDING' ? 'Pendiente' :
                               delivery.status === 'IN_PROGRESS' ? 'En Progreso' :
                               delivery.status === 'COMPLETED' ? 'Completado' : 'Cancelado'}
                            </Badge>
                          </p>
                          <p className="flex items-center gap-2">
                            <span className="text-gray-600">Artículos:</span>
                            <span>{delivery.items}</span>
                          </p>
                          <p className="flex items-center gap-2">
                            <span className="text-gray-600">Total:</span>
                            <span className="font-semibold">${delivery.total}</span>
                          </p>
                          {delivery.deliveryPerson && (
                            <p className="flex items-center gap-2">
                              <span className="text-gray-600">Repartidor:</span>
                              <span>{delivery.deliveryPerson.name}</span>
                            </p>
                          )}
                        </div>
                      </div>
                    </Popup>
                  </Marker>
                )
              ))}
            </MapContainer>
          </div>
        </CardContent>
      </Card>

      {/* Leyenda y Estadísticas */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Leyenda del Mapa SCM</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 bg-green-500 rounded-full border-2 border-white shadow"></div>
                <span className="text-sm">Repartidores Disponibles</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 bg-blue-500 rounded-full border-2 border-white shadow"></div>
                <span className="text-sm">Puntos de Entrega</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge className="bg-yellow-100 text-yellow-800">Pendiente</Badge>
                <span className="text-sm">Entrega pendiente</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge className="bg-blue-100 text-blue-800">En Progreso</Badge>
                <span className="text-sm">Entrega en curso</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Estadísticas SCM en Tiempo Real</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">{deliveryPersonsWithLocation.length}</p>
                <p className="text-sm text-gray-600">Repartidores Activos</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-600">
                  {deliveriesWithLocation.filter(d => d.status === 'IN_PROGRESS').length}
                </p>
                <p className="text-sm text-gray-600">Entregas en Curso</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}