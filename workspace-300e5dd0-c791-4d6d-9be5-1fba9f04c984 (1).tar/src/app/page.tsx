'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Package, MapPin, Clock, User, TrendingUp, AlertCircle, CheckCircle, Truck, Plus, Phone, Store, ShoppingCart, Tag, Settings, Users, Smartphone } from 'lucide-react'
import DeliveryMap from '@/components/DeliveryMap'
import AddressAutocomplete from '@/components/AddressAutocomplete'
import StoreLocationManager from '@/components/StoreLocationManager'

interface Delivery {
  id: string
  customerName: string
  customerAddress: string
  customerLat?: number
  customerLng?: number
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED'
  deliveryPerson?: {
    name: string
    phone: string
  }
  estimatedTime: string
  items: number
  total: number
  distance?: number
  estimatedArrival?: string
  createdAt: string
  notes?: string
  storeLocation?: {
    name: string
    address: string
    latitude: number
    longitude: number
  }
}

interface Customer {
  id: string
  name: string
  email?: string
  phone?: string
  address: string
  latitude?: number
  longitude?: number
  totalDeliveries: number
  totalSpent: number
}

interface DeliveryPerson {
  id: string
  name: string
  email?: string
  phone: string
  isAvailable: boolean
  activeDeliveries: number
  currentLat?: number
  currentLng?: number
}

interface StoreLocation {
  id: string
  name: string
  address: string
  latitude: number
  longitude: number
  phone?: string
  email?: string
  isActive: boolean
}

interface Product {
  id: string
  name: string
  description?: string
  price: number
  imageUrl?: string
  sku?: string
  stock: number
  isActive: boolean
  category: {
    id: string
    name: string
  }
}

interface Category {
  id: string
  name: string
  description?: string
  imageUrl?: string
  isActive: boolean
  _count: {
    products: number
  }
}

interface Branding {
  id: string
  companyName: string
  logoUrl?: string
  primaryColor: string
  secondaryColor: string
  accentColor: string
  slogan?: string
  description?: string
  website?: string
  socialMedia?: any
  contactInfo?: any
}

interface Stats {
  totalDeliveries: number
  pendingDeliveries: number
  inProgressDeliveries: number
  completedDeliveries: number
  totalRevenue: number
}

export default function DeliveryApp() {
  const [deliveries, setDeliveries] = useState<Delivery[]>([])
  const [customers, setCustomers] = useState<Customer[]>([])
  const [deliveryPersons, setDeliveryPersons] = useState<DeliveryPerson[]>([])
  const [stats, setStats] = useState<Stats>({
    totalDeliveries: 0,
    pendingDeliveries: 0,
    inProgressDeliveries: 0,
    completedDeliveries: 0,
    totalRevenue: 0
  })
  const [loading, setLoading] = useState(true)
  const [newDeliveryOpen, setNewDeliveryOpen] = useState(false)
  const [newCustomerOpen, setNewCustomerOpen] = useState(false)
  const [newDeliveryPersonOpen, setNewDeliveryPersonOpen] = useState(false)
  const [storeLocations, setStoreLocations] = useState<StoreLocation[]>([])
  const [selectedStoreId, setSelectedStoreId] = useState<string>('')
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [branding, setBranding] = useState<Branding | null>(null)

  const [newDelivery, setNewDelivery] = useState({
    customerName: '',
    customerAddress: '',
    customerLat: 0,
    customerLng: 0,
    items: 1,
    total: 0,
    estimatedTime: '30 min',
    notes: '',
    storeLocationId: ''
  })

  const [newCustomer, setNewCustomer] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    latitude: 0,
    longitude: 0
  })

  const [newDeliveryPerson, setNewDeliveryPerson] = useState({
    name: '',
    email: '',
    phone: ''
  })

  useEffect(() => {
    fetchData()
  }, [])

  const fetchData = async () => {
    try {
      const [deliveriesRes, customersRes, deliveryPersonsRes, statsRes, storesRes, productsRes, categoriesRes, brandingRes] = await Promise.all([
        fetch('/api/deliveries'),
        fetch('/api/customers'),
        fetch('/api/delivery-persons'),
        fetch('/api/stats'),
        fetch('/api/store-locations'),
        fetch('/api/products'),
        fetch('/api/categories'),
        fetch('/api/branding')
      ])

      const [deliveriesData, customersData, deliveryPersonsData, statsData, storesData, productsData, categoriesData, brandingData] = await Promise.all([
        deliveriesRes.json(),
        customersRes.json(),
        deliveryPersonsRes.json(),
        statsRes.json(),
        storesRes.json(),
        productsRes.json(),
        categoriesRes.json(),
        brandingRes.json()
      ])

      setDeliveries(deliveriesData)
      setCustomers(customersData)
      setDeliveryPersons(deliveryPersonsData)
      setStats(statsData)
      setStoreLocations(storesData)
      setProducts(productsData)
      setCategories(categoriesData)
      setBranding(brandingData)
      
      // Seleccionar la primera tienda activa por defecto
      const activeStore = storesData.find((store: StoreLocation) => store.isActive)
      if (activeStore) {
        setSelectedStoreId(activeStore.id)
        setNewDelivery(prev => ({ ...prev, storeLocationId: activeStore.id }))
      }
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setLoading(false)
    }
  }

  const createDelivery = async () => {
    try {
      const response = await fetch('/api/deliveries', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newDelivery),
      })

      if (response.ok) {
        setNewDeliveryOpen(false)
        setNewDelivery({
          customerName: '',
          customerAddress: '',
          customerLat: 0,
          customerLng: 0,
          items: 1,
          total: 0,
          estimatedTime: '30 min',
          notes: '',
          storeLocationId: selectedStoreId
        })
        fetchData()
      }
    } catch (error) {
      console.error('Error creating delivery:', error)
    }
  }

  const createCustomer = async () => {
    try {
      const response = await fetch('/api/customers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newCustomer),
      })

      if (response.ok) {
        setNewCustomerOpen(false)
        setNewCustomer({
          name: '',
          email: '',
          phone: '',
          address: ''
        })
        fetchData()
      }
    } catch (error) {
      console.error('Error creating customer:', error)
    }
  }

  const createDeliveryPerson = async () => {
    try {
      const response = await fetch('/api/delivery-persons', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newDeliveryPerson),
      })

      if (response.ok) {
        setNewDeliveryPersonOpen(false)
        setNewDeliveryPerson({
          name: '',
          email: '',
          phone: ''
        })
        fetchData()
      }
    } catch (error) {
      console.error('Error creating delivery person:', error)
    }
  }

  const updateDeliveryStatus = async (id: string, status: string, deliveryPersonId?: string) => {
    try {
      const response = await fetch(`/api/deliveries/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status, deliveryPersonId }),
      })

      if (response.ok) {
        fetchData()
      }
    } catch (error) {
      console.error('Error updating delivery:', error)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PENDING': return 'bg-yellow-100 text-yellow-800'
      case 'IN_PROGRESS': return 'bg-blue-100 text-blue-800'
      case 'COMPLETED': return 'bg-green-100 text-green-800'
      case 'CANCELLED': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'PENDING': return <Clock className="w-4 h-4" />
      case 'IN_PROGRESS': return <Truck className="w-4 h-4" />
      case 'COMPLETED': return <CheckCircle className="w-4 h-4" />
      case 'CANCELLED': return <AlertCircle className="w-4 h-4" />
      default: return <Package className="w-4 h-4" />
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'PENDING': return 'Pendiente'
      case 'IN_PROGRESS': return 'En Progreso'
      case 'COMPLETED': return 'Completado'
      case 'CANCELLED': return 'Cancelado'
      default: return status
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Cargando...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">SCM Fast Delivery</h1>
          <p className="text-gray-600">Gestiona tus entregas de manera eficiente y rápida</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Entregas</p>
                  <p className="text-2xl font-bold">{stats.totalDeliveries}</p>
                </div>
                <Package className="w-8 h-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Pendientes</p>
                  <p className="text-2xl font-bold text-yellow-600">{stats.pendingDeliveries}</p>
                </div>
                <Clock className="w-8 h-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">En Progreso</p>
                  <p className="text-2xl font-bold text-blue-600">{stats.inProgressDeliveries}</p>
                </div>
                <Truck className="w-8 h-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Completadas</p>
                  <p className="text-2xl font-bold text-green-600">{stats.completedDeliveries}</p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Ingresos</p>
                  <p className="text-2xl font-bold">${stats.totalRevenue}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="deliveries" className="space-y-6">
          <TabsList className="grid w-full grid-cols-8">
            <TabsTrigger value="deliveries">Entregas</TabsTrigger>
            <TabsTrigger value="map">Mapa GPS</TabsTrigger>
            <TabsTrigger value="customers">Clientes</TabsTrigger>
            <TabsTrigger value="stores">Locales</TabsTrigger>
            <TabsTrigger value="staff">Personal</TabsTrigger>
            <TabsTrigger value="products">Productos</TabsTrigger>
            <TabsTrigger value="branding">Branding</TabsTrigger>
            <TabsTrigger value="platforms">Plataformas</TabsTrigger>
          </TabsList>

          <TabsContent value="deliveries" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Gestión de Entregas SCM</h2>
              <Dialog open={newDeliveryOpen} onOpenChange={setNewDeliveryOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Nueva Entrega
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Crear Nueva Entrega SCM</DialogTitle>
                    <DialogDescription>
                      Ingresa los detalles de la nueva entrega SCM Fast Delivery
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="customerName">Nombre del Cliente</Label>
                      <Input
                        id="customerName"
                        value={newDelivery.customerName}
                        onChange={(e) => setNewDelivery({...newDelivery, customerName: e.target.value})}
                        placeholder="Ej: María García"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="storeLocation">Local de Origen</Label>
                      <Select 
                        value={newDelivery.storeLocationId} 
                        onValueChange={(value) => setNewDelivery({...newDelivery, storeLocationId: value})}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecciona un local" />
                        </SelectTrigger>
                        <SelectContent>
                          {storeLocations.filter(store => store.isActive).map((store) => (
                            <SelectItem key={store.id} value={store.id}>
                              {store.name} - {store.address}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="customerAddress">Dirección de Entrega</Label>
                      <AddressAutocomplete
                        value={newDelivery.customerAddress}
                        onChange={(address, coordinates) => {
                          setNewDelivery({
                            ...newDelivery, 
                            customerAddress: address,
                            customerLat: coordinates?.lat || 0,
                            customerLng: coordinates?.lng || 0
                          })
                        }}
                        placeholder="Ingresa la dirección de entrega..."
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="items">Número de Artículos</Label>
                        <Input
                          id="items"
                          type="number"
                          value={newDelivery.items}
                          onChange={(e) => setNewDelivery({...newDelivery, items: parseInt(e.target.value)})}
                          min="1"
                        />
                      </div>
                      <div>
                        <Label htmlFor="total">Total ($)</Label>
                        <Input
                          id="total"
                          type="number"
                          value={newDelivery.total}
                          onChange={(e) => setNewDelivery({...newDelivery, total: parseFloat(e.target.value)})}
                          min="0"
                          step="0.01"
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="estimatedTime">Tiempo Estimado</Label>
                      <Select value={newDelivery.estimatedTime} onValueChange={(value) => setNewDelivery({...newDelivery, estimatedTime: value})}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="15 min">15 minutos</SelectItem>
                          <SelectItem value="30 min">30 minutos</SelectItem>
                          <SelectItem value="45 min">45 minutos</SelectItem>
                          <SelectItem value="1 hora">1 hora</SelectItem>
                          <SelectItem value="1.5 horas">1.5 horas</SelectItem>
                          <SelectItem value="2 horas">2 horas</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="notes">Notas (Opcional)</Label>
                      <Textarea
                        id="notes"
                        value={newDelivery.notes}
                        onChange={(e) => setNewDelivery({...newDelivery, notes: e.target.value})}
                        placeholder="Instrucciones especiales..."
                      />
                    </div>
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" onClick={() => setNewDeliveryOpen(false)}>
                        Cancelar
                      </Button>
                      <Button onClick={createDelivery}>
                        Crear Entrega
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid gap-4">
              {deliveries.map((delivery) => (
                <Card key={delivery.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-semibold text-lg">{delivery.customerName}</h3>
                          <Badge className={getStatusColor(delivery.status)}>
                            <div className="flex items-center gap-1">
                              {getStatusIcon(delivery.status)}
                              <span>{getStatusText(delivery.status)}</span>
                            </div>
                          </Badge>
                        </div>
                        
                        <div className="space-y-2 text-sm text-gray-600">
                          <div className="flex items-center gap-2">
                            <MapPin className="w-4 h-4" />
                            <span>{delivery.customerAddress}</span>
                          </div>
                          
                          <div className="flex items-center gap-2">
                            <Package className="w-4 h-4" />
                            <span>{delivery.items} artículos</span>
                          </div>
                          
                          <div className="flex items-center gap-2">
                            <Clock className="w-4 h-4" />
                            <span>{delivery.estimatedTime}</span>
                          </div>
                          
                          {delivery.deliveryPerson && (
                            <div className="flex items-center gap-2">
                              <User className="w-4 h-4" />
                              <span>Repartidor: {delivery.deliveryPerson.name}</span>
                              <Phone className="w-3 h-3" />
                              <span>{delivery.deliveryPerson.phone}</span>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex flex-col items-end gap-2">
                        <div className="text-2xl font-bold text-green-600">${delivery.total}</div>
                        <div className="text-xs text-gray-500">
                          {new Date(delivery.createdAt).toLocaleString('es-MX')}
                        </div>
                        <div className="flex gap-2">
                          {delivery.status === 'PENDING' && (
                            <>
                              <Select onValueChange={(value) => updateDeliveryStatus(delivery.id, 'IN_PROGRESS', value)}>
                                <SelectTrigger className="w-32">
                                  <SelectValue placeholder="Asignar" />
                                </SelectTrigger>
                                <SelectContent>
                                  {deliveryPersons.map((person) => (
                                    <SelectItem key={person.id} value={person.id}>
                                      {person.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </>
                          )}
                          {delivery.status === 'IN_PROGRESS' && (
                            <Button 
                              size="sm" 
                              onClick={() => updateDeliveryStatus(delivery.id, 'COMPLETED')}
                            >
                              Completar
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="map" className="space-y-4">
            <DeliveryMap 
              deliveryPersons={deliveryPersons}
              deliveries={deliveries}
              onRefresh={fetchData}
            />
          </TabsContent>

          <TabsContent value="customers" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Clientes SCM</h2>
              <Dialog open={newCustomerOpen} onOpenChange={setNewCustomerOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Nuevo Cliente
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Agregar Nuevo Cliente SCM</DialogTitle>
                    <DialogDescription>
                      Ingresa la información del nuevo cliente para SCM Fast Delivery
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="name">Nombre</Label>
                      <Input
                        id="name"
                        value={newCustomer.name}
                        onChange={(e) => setNewCustomer({...newCustomer, name: e.target.value})}
                        placeholder="Ej: María García"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email (Opcional)</Label>
                      <Input
                        id="email"
                        type="email"
                        value={newCustomer.email}
                        onChange={(e) => setNewCustomer({...newCustomer, email: e.target.value})}
                        placeholder="ejemplo@email.com"
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone">Teléfono</Label>
                      <Input
                        id="phone"
                        value={newCustomer.phone}
                        onChange={(e) => setNewCustomer({...newCustomer, phone: e.target.value})}
                        placeholder="+52 123 456 7890"
                      />
                    </div>
                    <div>
                      <Label htmlFor="address">Dirección</Label>
                      <Input
                        id="address"
                        value={newCustomer.address}
                        onChange={(e) => setNewCustomer({...newCustomer, address: e.target.value})}
                        placeholder="Calle Principal #123"
                      />
                    </div>
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" onClick={() => setNewCustomerOpen(false)}>
                        Cancelar
                      </Button>
                      <Button onClick={createCustomer}>
                        Agregar Cliente
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid gap-4">
              {customers.map((customer) => (
                <Card key={customer.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                          <User className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-medium">{customer.name}</p>
                          <p className="text-sm text-gray-600">{customer.address}</p>
                          {customer.phone && (
                            <p className="text-sm text-gray-500 flex items-center gap-1">
                              <Phone className="w-3 h-3" />
                              {customer.phone}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">${customer.totalSpent}</p>
                        <p className="text-sm text-gray-600">{customer.totalDeliveries} entregas</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="staff" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Repartidores SCM</h2>
              <Dialog open={newDeliveryPersonOpen} onOpenChange={setNewDeliveryPersonOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Nuevo Repartidor
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Agregar Nuevo Repartidor SCM</DialogTitle>
                    <DialogDescription>
                      Ingresa la información del nuevo repartidor para SCM Fast Delivery
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="name">Nombre</Label>
                      <Input
                        id="name"
                        value={newDeliveryPerson.name}
                        onChange={(e) => setNewDeliveryPerson({...newDeliveryPerson, name: e.target.value})}
                        placeholder="Ej: Carlos López"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email (Opcional)</Label>
                      <Input
                        id="email"
                        type="email"
                        value={newDeliveryPerson.email}
                        onChange={(e) => setNewDeliveryPerson({...newDeliveryPerson, email: e.target.value})}
                        placeholder="ejemplo@email.com"
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone">Teléfono</Label>
                      <Input
                        id="phone"
                        value={newDeliveryPerson.phone}
                        onChange={(e) => setNewDeliveryPerson({...newDeliveryPerson, phone: e.target.value})}
                        placeholder="+52 123 456 7890"
                      />
                    </div>
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" onClick={() => setNewDeliveryPersonOpen(false)}>
                        Cancelar
                      </Button>
                      <Button onClick={createDeliveryPerson}>
                        Agregar Repartidor
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid gap-4">
              {deliveryPersons.map((person) => (
                <Card key={person.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                          <Truck className="w-5 h-5 text-green-600" />
                        </div>
                        <div>
                          <p className="font-medium">{person.name}</p>
                          <p className="text-sm text-gray-600 flex items-center gap-1">
                            <Phone className="w-3 h-3" />
                            {person.phone}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge className={person.isAvailable ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                          {person.isAvailable ? 'Disponible' : 'Ocupado'}
                        </Badge>
                        <p className="text-sm text-gray-600 mt-1">{person.activeDeliveries} entregas activas</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="products" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Catálogo de Productos</h2>
              <div className="flex gap-2">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline">
                      <Tag className="w-4 h-4 mr-2" />
                      Nueva Categoría
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Crear Nueva Categoría</DialogTitle>
                      <DialogDescription>
                        Agrega una nueva categoría para organizar tus productos
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="categoryName">Nombre de la Categoría</Label>
                        <Input
                          id="categoryName"
                          placeholder="Ej: Bebidas, Comida, Electrónica"
                        />
                      </div>
                      <div>
                        <Label htmlFor="categoryDescription">Descripción</Label>
                        <Textarea
                          id="categoryDescription"
                          placeholder="Describe esta categoría..."
                        />
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button>
                      <ShoppingCart className="w-4 h-4 mr-2" />
                      Nuevo Producto
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Agregar Nuevo Producto</DialogTitle>
                      <DialogDescription>
                        Ingresa los detalles del nuevo producto para el catálogo
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="productName">Nombre del Producto</Label>
                        <Input
                          id="productName"
                          placeholder="Ej: Pizza Grande"
                        />
                      </div>
                      <div>
                        <Label htmlFor="productCategory">Categoría</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecciona una categoría" />
                          </SelectTrigger>
                          <SelectContent>
                            {categories.map((category) => (
                              <SelectItem key={category.id} value={category.id}>
                                {category.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="productDescription">Descripción</Label>
                        <Textarea
                          id="productDescription"
                          placeholder="Describe el producto..."
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="productPrice">Precio ($)</Label>
                          <Input
                            id="productPrice"
                            type="number"
                            placeholder="0.00"
                            step="0.01"
                          />
                        </div>
                        <div>
                          <Label htmlFor="productStock">Stock</Label>
                          <Input
                            id="productStock"
                            type="number"
                            placeholder="0"
                          />
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="productSku">SKU (Opcional)</Label>
                        <Input
                          id="productSku"
                          placeholder="Ej: PROD-001"
                        />
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {categories.map((category) => (
                <Card key={category.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{category.name}</CardTitle>
                      <Badge variant="secondary">{category._count.products} productos</Badge>
                    </div>
                    {category.description && (
                      <CardDescription>{category.description}</CardDescription>
                    )}
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {products
                        .filter(product => product.categoryId === category.id)
                        .map((product) => (
                          <div key={product.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                            <div>
                              <p className="font-medium text-sm">{product.name}</p>
                              <p className="text-xs text-gray-600">${product.price} • Stock: {product.stock}</p>
                            </div>
                            <Badge className={product.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                              {product.isActive ? 'Activo' : 'Inactivo'}
                            </Badge>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="branding" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Branding y Marketing</h2>
              <Button>
                <Settings className="w-4 h-4 mr-2" />
                Configurar Branding
              </Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Información de la Empresa</CardTitle>
                  <CardDescription>
                    Configura la identidad visual y información de tu marca
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="companyName">Nombre de la Empresa</Label>
                    <Input
                      id="companyName"
                      defaultValue={branding?.companyName || 'SCM Fast Delivery'}
                    />
                  </div>
                  <div>
                    <Label htmlFor="slogan">Slogan</Label>
                    <Input
                      id="slogan"
                      placeholder="Ej: Entrega rápida donde quieras"
                      defaultValue={branding?.slogan || ''}
                    />
                  </div>
                  <div>
                    <Label htmlFor="description">Descripción</Label>
                    <Textarea
                      id="description"
                      placeholder="Describe tu empresa..."
                      defaultValue={branding?.description || ''}
                    />
                  </div>
                  <div>
                    <Label htmlFor="website">Sitio Web</Label>
                    <Input
                      id="website"
                      type="url"
                      placeholder="https://tu-sitio-web.com"
                      defaultValue={branding?.website || ''}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Colores de Marca</CardTitle>
                  <CardDescription>
                    Define la paleta de colores de tu marca
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="primaryColor">Color Primario</Label>
                    <div className="flex gap-2">
                      <Input
                        id="primaryColor"
                        type="color"
                        defaultValue={branding?.primaryColor || '#000000'}
                      />
                      <Input
                        defaultValue={branding?.primaryColor || '#000000'}
                        placeholder="#000000"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="secondaryColor">Color Secundario</Label>
                    <div className="flex gap-2">
                      <Input
                        id="secondaryColor"
                        type="color"
                        defaultValue={branding?.secondaryColor || '#ffffff'}
                      />
                      <Input
                        defaultValue={branding?.secondaryColor || '#ffffff'}
                        placeholder="#ffffff"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="accentColor">Color de Acento</Label>
                    <div className="flex gap-2">
                      <Input
                        id="accentColor"
                        type="color"
                        defaultValue={branding?.accentColor || '#3b82f6'}
                      />
                      <Input
                        defaultValue={branding?.accentColor || '#3b82f6'}
                        placeholder="#3b82f6"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Redes Sociales</CardTitle>
                  <CardDescription>
                    Configura tus redes sociales
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="facebook">Facebook</Label>
                    <Input
                      id="facebook"
                      placeholder="https://facebook.com/tu-pagina"
                    />
                  </div>
                  <div>
                    <Label htmlFor="twitter">Twitter/X</Label>
                    <Input
                      id="twitter"
                      placeholder="https://twitter.com/tu-perfil"
                    />
                  </div>
                  <div>
                    <Label htmlFor="instagram">Instagram</Label>
                    <Input
                      id="instagram"
                      placeholder="https://instagram.com/tu-perfil"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Información de Contacto</CardTitle>
                  <CardDescription>
                    Datos de contacto para clientes
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="contactPhone">Teléfono de Contacto</Label>
                    <Input
                      id="contactPhone"
                      placeholder="+52 123 456 7890"
                    />
                  </div>
                  <div>
                    <Label htmlFor="contactEmail">Email de Contacto</Label>
                    <Input
                      id="contactEmail"
                      type="email"
                      placeholder="contacto@empresa.com"
                    />
                  </div>
                  <div>
                    <Label htmlFor="contactAddress">Dirección</Label>
                    <Textarea
                      id="contactAddress"
                      placeholder="Dirección completa de la empresa..."
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="platforms" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Plataformas Digitales</h2>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Users className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <CardTitle>Plataforma de Clientes</CardTitle>
                      <CardDescription>
                        Portal web para que los clientes realicen pedidos
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      Catálogo de productos interactivo
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      Sistema de pedidos online
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      Seguimiento de entregas en tiempo real
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      Historial de pedidos y facturación
                    </div>
                    <Button className="w-full mt-4">
                      Acceder a Plataforma de Clientes
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                      <Smartphone className="w-6 h-6 text-green-600" />
                    </div>
                    <div>
                      <CardTitle>App de Repartidores</CardTitle>
                      <CardDescription>
                        Aplicación móvil para repartidores
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      Recepción de pedidos en tiempo real
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      Navegación GPS integrada
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      Confirmación de entregas
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      Comunicación con clientes
                    </div>
                    <div className="grid grid-cols-2 gap-2 mt-4">
                      <Button variant="outline" className="text-xs">
                        <Smartphone className="w-3 h-3 mr-1" />
                        Android
                      </Button>
                      <Button variant="outline" className="text-xs">
                        <Smartphone className="w-3 h-3 mr-1" />
                        iOS
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Estadísticas de Uso de Plataformas</CardTitle>
                <CardDescription>
                    Métricas de rendimiento de las plataformas digitales
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <p className="text-2xl font-bold text-blue-600">1,234</p>
                    <p className="text-sm text-gray-600">Usuarios Activos</p>
                  </div>
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <p className="text-2xl font-bold text-green-600">89</p>
                    <p className="text-sm text-gray-600">Repartidores Activos</p>
                  </div>
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <p className="text-2xl font-bold text-purple-600">5,678</p>
                    <p className="text-sm text-gray-600">Pedidos Procesados</p>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <p className="text-2xl font-bold text-orange-600">98.5%</p>
                    <p className="text-sm text-gray-600">Satisfacción</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}