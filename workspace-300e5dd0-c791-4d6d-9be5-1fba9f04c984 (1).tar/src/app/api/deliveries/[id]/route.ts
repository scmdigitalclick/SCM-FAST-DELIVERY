import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const delivery = await db.delivery.findUnique({
      where: { id: params.id },
      include: {
        customer: true,
        deliveryPerson: true
      }
    })

    if (!delivery) {
      return NextResponse.json(
        { error: 'Delivery not found' },
        { status: 404 }
      )
    }

    return NextResponse.json(delivery)
  } catch (error) {
    console.error('Error fetching delivery:', error)
    return NextResponse.json(
      { error: 'Error fetching delivery' },
      { status: 500 }
    )
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const { status, deliveryPersonId } = body

    const updateData: any = { status }
    
    if (deliveryPersonId) {
      updateData.deliveryPersonId = deliveryPersonId
    }
    
    if (status === 'COMPLETED') {
      updateData.completedAt = new Date()
    }

    const delivery = await db.delivery.update({
      where: { id: params.id },
      data: updateData,
      include: {
        customer: true,
        deliveryPerson: true
      }
    })

    return NextResponse.json(delivery)
  } catch (error) {
    console.error('Error updating delivery:', error)
    return NextResponse.json(
      { error: 'Error updating delivery' },
      { status: 500 }
    )
  }
}