import { NextRequest, NextResponse } from 'next/server'

// Usaremos Nominatim de OpenStreetMap para geocodificación gratuita
const NOMINATIM_BASE_URL = 'https://nominatim.openstreetmap.org/search'

export async function POST(request: NextRequest) {
  try {
    const { address } = await request.json()

    if (!address) {
      return NextResponse.json(
        { error: 'La dirección es requerida' },
        { status: 400 }
      )
    }

    // Geocodificación usando Nominatim (OpenStreetMap)
    const response = await fetch(
      `${NOMINATIM_BASE_URL}?q=${encodeURIComponent(address)}&format=json&limit=1&countrycodes=mx`,
      {
        headers: {
          'User-Agent': 'SCM Fast Delivery (contact@scmfastdelivery.com)'
        }
      }
    )

    if (!response.ok) {
      throw new Error('Error en la geocodificación')
    }

    const data = await response.json()

    if (data.length === 0) {
      return NextResponse.json(
        { error: 'No se encontró la dirección' },
        { status: 404 }
      )
    }

    const result = data[0]
    const coordinates = {
      lat: parseFloat(result.lat),
      lng: parseFloat(result.lon),
      address: result.display_name,
      confidence: result.importance || 0
    }

    return NextResponse.json(coordinates)
  } catch (error) {
    console.error('Error en geocodificación:', error)
    return NextResponse.json(
      { error: 'Error al procesar la dirección' },
      { status: 500 }
    )
  }
}

// Reverse geocoding - obtener dirección desde coordenadas
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const lat = searchParams.get('lat')
    const lng = searchParams.get('lng')

    if (!lat || !lng) {
      return NextResponse.json(
        { error: 'Latitud y longitud son requeridas' },
        { status: 400 }
      )
    }

    const response = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&countrycodes=mx`,
      {
        headers: {
          'User-Agent': 'SCM Fast Delivery (contact@scmfastdelivery.com)'
        }
      }
    )

    if (!response.ok) {
      throw new Error('Error en la geocodificación inversa')
    }

    const data = await response.json()

    return NextResponse.json({
      address: data.display_name,
      components: data.address,
      lat: parseFloat(data.lat),
      lng: parseFloat(data.lon)
    })
  } catch (error) {
    console.error('Error en geocodificación inversa:', error)
    return NextResponse.json(
      { error: 'Error al obtener la dirección' },
      { status: 500 }
    )
  }
}