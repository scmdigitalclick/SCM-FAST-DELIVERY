'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Truck, MapPin, Clock, Phone, CheckCircle, Navigation, Package, User, DollarSign, AlertCircle, Star } from 'lucide-react'

interface Delivery {
  id: string
  customerName: string
  customerAddress: string
  customerLat?: number
  customerLng?: number
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED'
  items: number
  total: number
  estimatedTime: string
  distance?: number
  notes?: string
  createdAt: string
  storeLocation?: {
    name: string
    address: string
    latitude: number
    longitude: number
  }
}

interface DeliveryPerson {
  id: string
  name: string
  phone: string
  isAvailable: boolean
  currentLat?: number
  currentLng?: number
  totalDeliveries: number
  totalEarnings: number
  rating: number
}

export default function DeliveryApp() {
  const [deliveries, setDeliveries] = useState<Delivery[]>([])
  const [deliveryPerson, setDeliveryPerson] = useState<DeliveryPerson | null>(null)
  const [selectedDelivery, setSelectedDelivery] = useState<Delivery | null>(null)
  const [loading, setLoading] = useState(true)
  const [isOnline, setIsOnline] = useState(false)
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null)

  const [deliveryNotes, setDeliveryNotes] = useState('')
  const [completionDialogOpen, setCompletionDialogOpen] = useState(false)

  useEffect(() => {
    // Simulate delivery person data
    setDeliveryPerson({
      id: '1',
      name: 'Carlos López',
      phone: '+52 123 456 7890',
      isAvailable: true,
      currentLat: 19.4326,
      currentLng: -99.1332,
      totalDeliveries: 156,
      totalEarnings: 45680,
      rating: 4.8
    })

    fetchAvailableDeliveries()
    getCurrentLocation()
  }, [])

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          })
        },
        (error) => {
          console.error('Error getting location:', error)
        }
      )
    }
  }

  const fetchAvailableDeliveries = async () => {
    try {
      const response = await fetch('/api/deliveries?status=PENDING')
      const data = await response.json()
      setDeliveries(data)
    } catch (error) {
      console.error('Error fetching deliveries:', error)
    } finally {
      setLoading(false)
    }
  }

  const acceptDelivery = async (delivery: Delivery) => {
    try {
      const response = await fetch(`/api/deliveries/${delivery.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          status: 'IN_PROGRESS',
          deliveryPersonId: deliveryPerson?.id 
        }),
      })

      if (response.ok) {
        setSelectedDelivery(delivery)
        fetchAvailableDeliveries()
      }
    } catch (error) {
      console.error('Error accepting delivery:', error)
    }
  }

  const completeDelivery = async () => {
    if (!selectedDelivery) return

    try {
      const response = await fetch(`/api/deliveries/${selectedDelivery.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          status: 'COMPLETED',
          notes: deliveryNotes 
        }),
      })

      if (response.ok) {
        setSelectedDelivery(null)
        setDeliveryNotes('')
        setCompletionDialogOpen(false)
        fetchAvailableDeliveries()
        
        // Update delivery person stats
        if (deliveryPerson) {
          setDeliveryPerson({
            ...deliveryPerson,
            totalDeliveries: deliveryPerson.totalDeliveries + 1,
            totalEarnings: deliveryPerson.totalEarnings + (selectedDelivery.total * 0.1) // 10% commission
          })
        }
      }
    } catch (error) {
      console.error('Error completing delivery:', error)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PENDING': return 'bg-yellow-100 text-yellow-800'
      case 'IN_PROGRESS': return 'bg-blue-100 text-blue-800'
      case 'COMPLETED': return 'bg-green-100 text-green-800'
      case 'CANCELLED': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'PENDING': return 'Pendiente'
      case 'IN_PROGRESS': return 'En Progreso'
      case 'COMPLETED': return 'Completado'
      case 'CANCELLED': return 'Cancelado'
      default: return status
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Cargando entregas...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center">
                <Truck className="w-5 h-5 text-white" />
              </div>
              <h1 className="text-xl font-bold text-gray-900">SCM Delivery App</h1>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${isOnline ? 'bg-green-500' : 'bg-red-500'}`}></div>
                <span className="text-sm font-medium">
                  {isOnline ? 'En línea' : 'Fuera de línea'}
                </span>
              </div>
              
              <Button
                variant={isOnline ? 'default' : 'outline'}
                onClick={() => setIsOnline(!isOnline)}
              >
                {isOnline ? 'Desconectar' : 'Conectar'}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Delivery Person Info */}
        {deliveryPerson && (
          <Card className="mb-8">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                    <User className="w-8 h-8 text-green-600" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold">{deliveryPerson.name}</h2>
                    <p className="text-gray-600 flex items-center gap-1">
                      <Phone className="w-4 h-4" />
                      {deliveryPerson.phone}
                    </p>
                    <div className="flex items-center gap-2 mt-1">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-yellow-500 fill-current" />
                        <span className="font-medium">{deliveryPerson.rating}</span>
                      </div>
                      <span className="text-gray-400">•</span>
                      <span className="text-gray-600">{deliveryPerson.totalDeliveries} entregas</span>
                    </div>
                  </div>
                </div>
                
                <div className="text-right">
                  <p className="text-sm text-gray-600">Ganancias Totales</p>
                  <p className="text-2xl font-bold text-green-600">${deliveryPerson.totalEarnings}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Current Delivery */}
        {selectedDelivery && (
          <Card className="mb-8 border-blue-200 bg-blue-50">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-blue-800">Entrega en Progreso</CardTitle>
                <Badge className="bg-blue-100 text-blue-800">
                  <Truck className="w-3 h-3 mr-1" />
                  Activa
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-3">Información del Cliente</h3>
                  <div className="space-y-2">
                    <p className="flex items-center gap-2">
                      <User className="w-4 h-4 text-gray-500" />
                      {selectedDelivery.customerName}
                    </p>
                    <p className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-gray-500" />
                      {selectedDelivery.customerAddress}
                    </p>
                    <p className="flex items-center gap-2">
                      <Package className="w-4 h-4 text-gray-500" />
                      {selectedDelivery.items} artículos
                    </p>
                    <p className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-gray-500" />
                      ${selectedDelivery.total}
                    </p>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-semibold mb-3">Acciones</h3>
                  <div className="space-y-2">
                    <Button className="w-full" variant="outline">
                      <Navigation className="w-4 h-4 mr-2" />
                      Navegar a Dirección
                    </Button>
                    <Button className="w-full" variant="outline">
                      <Phone className="w-4 h-4 mr-2" />
                      Llamar al Cliente
                    </Button>
                    <Dialog open={completionDialogOpen} onOpenChange={setCompletionDialogOpen}>
                      <DialogTrigger asChild>
                        <Button className="w-full bg-green-600 hover:bg-green-700">
                          <CheckCircle className="w-4 h-4 mr-2" />
                          Completar Entrega
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Completar Entrega</DialogTitle>
                          <DialogDescription>
                            Confirma la entrega y agrega notas si es necesario
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="deliveryNotes">Notas de Entrega</Label>
                            <Textarea
                              id="deliveryNotes"
                              value={deliveryNotes}
                              onChange={(e) => setDeliveryNotes(e.target.value)}
                              placeholder="¿Cómo fue la entrega? ¿Algún problema?"
                            />
                          </div>
                          <div className="flex gap-2">
                            <Button variant="outline" onClick={() => setCompletionDialogOpen(false)}>
                              Cancelar
                            </Button>
                            <Button onClick={completeDelivery}>
                              Confirmar Completado
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Available Deliveries */}
        <div>
          <h2 className="text-2xl font-bold mb-4">Entregas Disponibles</h2>
          
          {deliveries.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-600 mb-2">No hay entregas disponibles</h3>
                <p className="text-gray-500">Las nuevas entregas aparecerán aquí cuando estén disponibles.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {deliveries.map((delivery) => (
                <Card key={delivery.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-3">
                          <Badge className={getStatusColor(delivery.status)}>
                            {getStatusText(delivery.status)}
                          </Badge>
                          <span className="text-sm text-gray-500">
                            {new Date(delivery.createdAt).toLocaleTimeString()}
                          </span>
                        </div>
                        
                        <h3 className="font-semibold text-lg mb-2">{delivery.customerName}</h3>
                        <p className="text-gray-600 mb-3 flex items-center gap-2">
                          <MapPin className="w-4 h-4" />
                          {delivery.customerAddress}
                        </p>
                        
                        <div className="flex items-center gap-4 text-sm text-gray-600">
                          <span className="flex items-center gap-1">
                            <Package className="w-4 h-4" />
                            {delivery.items} artículos
                          </span>
                          <span className="flex items-center gap-1">
                            <DollarSign className="w-4 h-4" />
                            ${delivery.total}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {delivery.estimatedTime}
                          </span>
                          {delivery.distance && (
                            <span className="flex items-center gap-1">
                              <Navigation className="w-4 h-4" />
                              {delivery.distance} km
                            </span>
                          )}
                        </div>
                        
                        {delivery.storeLocation && (
                          <p className="text-sm text-gray-500 mt-2">
                            Desde: {delivery.storeLocation.name}
                          </p>
                        )}
                      </div>
                      
                      <div className="flex flex-col gap-2">
                        <Button
                          onClick={() => acceptDelivery(delivery)}
                          disabled={!isOnline || !!selectedDelivery}
                          className="whitespace-nowrap"
                        >
                          <Truck className="w-4 h-4 mr-2" />
                          Aceptar
                        </Button>
                        <Button variant="outline" size="sm">
                          <Navigation className="w-4 h-4 mr-2" />
                          Ver Ruta
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}