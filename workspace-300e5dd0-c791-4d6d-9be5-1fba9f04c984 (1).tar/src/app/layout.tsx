import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "SCM Fast Delivery - Sistema de Entregas Rápidas",
  description: "Sistema de gestión de entregas rápido y eficiente. Controla tu fleet de repartidores, rastrea entregas en tiempo real y optimiza tu operación de delivery.",
  keywords: ["SCM Fast Delivery", "delivery", "entregas", "repartidores", "logística", "rastreo GPS", "sistema de delivery"],
  authors: [{ name: "SCM Fast Delivery Team" }],
  icons: {
    icon: "/favicon.ico",
  },
  openGraph: {
    title: "SCM Fast Delivery - Entregas Rápidas",
    description: "Sistema de gestión de entregas rápido y eficiente con rastreo en tiempo real",
    url: "https://scm-fast-delivery.com",
    siteName: "SCM Fast Delivery",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "SCM Fast Delivery - Entregas Rápidas",
    description: "Sistema de gestión de entregas rápido y eficiente con rastreo en tiempo real",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
