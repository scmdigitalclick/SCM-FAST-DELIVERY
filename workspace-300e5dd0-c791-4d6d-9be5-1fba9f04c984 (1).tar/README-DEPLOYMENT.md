# 🚀 Guía de Despliegue Rápida - Vercel

## 📋 Requisitos Previos

1. **Cuenta en Vercel** (gratis en [vercel.com](https://vercel.com))
2. **GitHub** (opcional pero recomendado)
3. **5 minutos** de tu tiempo

---

## 🎯 Paso 1: Subir a Vercel

### Opción A: Directo desde GitHub (Recomendado)
```bash
# 1. Subir tu código a GitHub
git add .
git commit -m "Ready for deployment"
git push origin main

# 2. Conectar con Vercel
# - Ve a vercel.com
# - Importa tu repositorio de GitHub
# - Click en "Deploy"
```

### Opción B: Vercel CLI (Más rápido)
```bash
# 1. Instalar Vercel CLI
npm i -g vercel

# 2. Login en Vercel
vercel login

# 3. Desplegar
vercel

# 4. Desplegar en producción
vercel --prod
```

---

## 🔧 Paso 2: Configurar Variables de Entorno

En Vercel Dashboard → Settings → Environment Variables:

```bash
# Base de datos
DATABASE_URL="file:./dev.db"

# NextAuth
NEXTAUTH_URL="https://tu-dominio.vercel.app"
NEXTAUTH_SECRET="tu-secreto-unico"

# App URL
NEXT_PUBLIC_APP_URL="https://tu-dominio.vercel.app"
```

---

## 🗄️ Paso 3: Configurar Base de Datos

### Opción A: SQLite (Gratis - Para empezar)
```bash
# Vercel ya incluye SQLite
# Solo necesitas la variable de entorno:
DATABASE_URL="file:./dev.db"
```

### Opción B: Vercel Postgres (Más robusto)
```bash
# 1. En Vercel Dashboard → Storage → Create Database
# 2. Elegir Postgres
# 3. Copiar la URL de conexión
# 4. Actualizar variable DATABASE_URL
```

---

## 🌐 Paso 4: Acceso a las Plataformas

Una vez desplegado, tendrás acceso a:

### 🔧 **Panel Administrativo**
```
https://tu-dominio.vercel.app
```
- Gestión de productos
- Gestión de categorías  
- Configuración de branding
- Gestión de entregas

### 🛒 **Plataforma de Clientes**
```
https://tu-dominio.vercel.app/customer-platform
```
- Catálogo de productos
- Carrito de compras
- Sistema de pedidos
- Seguimiento de entregas

### 📱 **App de Repartidores**
```
https://tu-dominio.vercel.app/delivery-app
```
- Panel de entregas disponibles
- Navegación GPS
- Gestión de pedidos
- Estadísticas y ganancias

---

## 📊 Paso 5: Probar Funcionalidades

### ✅ Checklist de Pruebas

#### **Panel Admin**
- [ ] Crear categorías
- [ ] Agregar productos
- [ ] Configurar branding
- [ ] Crear tienda/local

#### **Plataforma Clientes**
- [ ] Navegar catálogo
- [ ] Agregar productos al carrito
- [ ] Realizar pedido
- [ ] Ver confirmación

#### **App Repartidores**
- [ ] Ver entregas disponibles
- [ ] Aceptar entrega
- [ ] Simular navegación
- [ ] Completar entrega

---

## 🎨 Paso 6: Personalización

### Cambiar Colores y Branding
1. Ve al panel admin
2. Click en "Branding" 
3. Configura:
   - Nombre de empresa
   - Colores de marca
   - Logo
   - Redes sociales

### Agregar Dominio Personalizado
```bash
# 1. En Vercel Dashboard → Settings → Domains
# 2. Agrega tu-dominio.com
# 3. Configura DNS según instrucciones
# 4. Espera propagación (5-30 min)
```

---

## 📱 Paso 7: Apps Móviles (Opcional)

### PWA (Progressive Web App)
```bash
# Ya está configurado para funcionar como PWA
# Los usuarios pueden "instalar" la app desde el navegador
```

### Acceso desde Móvil
- **Clientes**: Guardar como acceso directo a pantalla de inicio
- **Repartidores**: Instalar PWA para experiencia nativa

---

## 💰 Costos

### Plan Gratuito (Vercel Hobby)
- ✅ **$0/mes**
- ✅ 100GB bandwidth/mes
- ✅ SSL automático
- ✅ CDN global
- ✅ Base de datos SQLite

### Plan Pro (Si creces)
- 💰 **$20/mes**
- ✅ Sin límites de bandwidth
- ✅ Dominios ilimitados
- ✅ Analytics avanzado

---

## 🚨 Solución de Problemas

### Error: "Database connection failed"
```bash
# Verifica variable DATABASE_URL
# Asegúrate que apunte a: "file:./dev.db"
```

### Error: "NextAuth secret missing"
```bash
# Genera un secreto único:
openssl rand -base64 32

# Configura en Vercel:
NEXTAUTH_SECRET="tu-secreto-generado"
```

### Error: "Build failed"
```bash
# Verifica que todos los archivos estén en GitHub
# Ejecuta localmente: npm run build
```

---

## 📈 Próximos Pasos

### **Semana 1: Pruebas**
- Probar con clientes reales
- Entrenar repartidores
- Recopilar feedback

### **Semana 2: Optimización**
- Agregar más productos
- Configurar dominio personalizado
- Implementar analytics

### **Mes 2: Escalamiento**
- Considerar Vercel Postgres
- Desarrollar app nativa
- Integración con WordPress

---

## 🎯 ¡Listo para Empezar!

### **En 5 minutos tendrás:**
1. ✅ Sistema de delivery funcionando
2. ✅ Plataforma para clientes
3. ✅ App para repartidores  
4. ✅ Panel de administración
5. ✅ Todo conectado y operativo

### **Links de Acceso:**
- **Admin**: `https://tu-dominio.vercel.app`
- **Clientes**: `https://tu-dominio.vercel.app/customer-platform`
- **Repartidores**: `https://tu-dominio.vercel.app/delivery-app`

¿Listo para desplegar? ¿Necesitas ayuda con algún paso específico?