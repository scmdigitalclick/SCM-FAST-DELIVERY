# 🚀 Inicio Rápido - SCM Fast Delivery

## Descarga e Instalación en 5 Minutos

### 1️⃣ Descargar el Proyecto
```bash
# Opción A: Descargar ZIP
# 1. Descarga el archivo ZIP del proyecto
# 2. Descomprime en tu carpeta
# 3. Abre la terminal en esa carpeta

# Opción B: Clonar con Git
git clone [URL-del-proyecto]
cd scm-fast-delivery
```

### 2️⃣ Instalar Dependencias
```bash
npm install
```

### 3️⃣ Configurar Base de Datos
```bash
npx prisma db push
```

### 4️⃣ Iniciar la Aplicación
```bash
npm run dev
```

### 5️⃣ Listo! 🎉
Abre tu navegador en: **http://localhost:3000**

---

## 📱 Acceso Rápido

| Plataforma | URL | Usuario | Contraseña |
|------------|-----|---------|------------|
| 🏪 Tienda Principal | http://localhost:3000 | cliente@demo.com | cliente123 |
| 👑 Administración | http://localhost:3000/admin | admin@scmfastdelivery.com | admin123 |
| 🚚 Delivery App | http://localhost:3000/delivery | repartidor@demo.com | repartidor123 |

---

## 🎯 Qué Puedes Hacer

### 🛒 Como Cliente
- Navegar por el catálogo de productos
- Agregar al carrito
- Realizar pedidos
- Seguir tu entrega en tiempo real

### 👑 Como Administrador
- Gestionar productos y categorías
- Ver todos los pedidos
- Administrar clientes y repartidores
- Ver estadísticas y reportes

### 🚚 Como Repartidor
- Ver pedidos asignados
- Actualizar estado de entregas
- Usar GPS para navegación
- Completar entregas

---

## 🔧 Si Tienes Problemas

### Error Común: "Puerto 3000 ocupado"
```bash
# Matar proceso en puerto 3000
npx kill-port 3000
```

### Error Común: "Base de datos no conecta"
```bash
# Reconfigurar base de datos
npx prisma db push
```

### Error Común: "Dependencias faltantes"
```bash
# Reinstalar todo
rm -rf node_modules package-lock.json
npm install
```

---

## 📞 Ayuda Adicional

- **Documentación completa**: `README_SETUP.md`
- **Ver base de datos**: `npx prisma studio`
- **Ver errores**: `npm run lint`

**¡Disfruta de SCM Fast Delivery!** 🎊