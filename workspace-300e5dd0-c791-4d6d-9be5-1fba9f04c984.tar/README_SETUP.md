# SCM Fast Delivery - Guía de Descarga e Instalación

## 📦 Descarga del Proyecto

### Opción 1: Descarga Directa del Código
1. **Accede al código fuente** del proyecto SCM Fast Delivery
2. **Descarga los archivos** en formato ZIP o clona el repositorio
3. **Descomprime** el archivo en tu carpeta de trabajo preferida

### Opción 2: Clonación con Git
```bash
git clone [URL-del-repositorio]
cd scm-fast-delivery
```

## 🚀 Requisitos Previos

### Software Necesario
- **Node.js** (versión 18 o superior)
- **npm** o **yarn** (gestor de paquetes)
- **Git** (para control de versiones)
- **VS Code** o tu editor de código preferido

### Verificación de Node.js
```bash
node --version
npm --version
```

## 🛠️ Instalación Paso a Paso

### 1. Instalar Dependencias
```bash
npm install
```

### 2. Configurar Variables de Entorno
Crea un archivo `.env.local` en la raíz del proyecto:

```env
# Database
DATABASE_URL="file:./dev.db"

# NextAuth
NEXTAUTH_URL="http://localhost:3000"
NEXTAUTH_SECRET="tu-secreto-aqui"

# API Keys (opcional)
OPENAI_API_KEY="tu-api-key-aqui"
```

### 3. Configurar Base de Datos
```bash
# Generar Prisma Client
npx prisma generate

# Crear base de datos y tablas
npx prisma db push

# (Opcional) Ver base de datos
npx prisma studio
```

### 4. Iniciar Servidor de Desarrollo
```bash
npm run dev
```

La aplicación estará disponible en: **http://localhost:3000**

## 📱 Acceso a las Plataformas

### 1. Plataforma de Administración
- **URL**: `http://localhost:3000/admin`
- **Acceso**: Credenciales de administrador
- **Funciones**: Gestión completa del sistema

### 2. Plataforma de Clientes
- **URL**: `http://localhost:3000`
- **Acceso**: Registro gratuito o inicio de sesión
- **Funciones**: Catálogo de productos, pedidos, seguimiento

### 3. App de Delivery
- **URL**: `http://localhost:3000/delivery`
- **Acceso**: Credenciales de repartidor
- **Funciones**: Gestión de entregas, GPS, estados

## 🔧 Configuración Adicional

### Credenciales por Defecto
```
Administrador:
- Email: admin@scmfastdelivery.com
- Contraseña: admin123

Cliente Demo:
- Email: cliente@demo.com
- Contraseña: cliente123

Repartidor Demo:
- Email: repartidor@demo.com
- Contraseña: repartidor123
```

### Configuración de Productos
1. Ingresa al panel de administración
2. Ve a "Productos" → "Añadir Producto"
3. Configura nombre, precio, descripción e imagen
4. Define categorías y disponibilidad

### Configuración de Tiendas
1. En el panel admin → "Tiendas"
2. Añade información de la tienda
3. Configura horarios y cobertura

## 📋 Estructura del Proyecto

```
scm-fast-delivery/
├── src/
│   ├── app/                 # Páginas Next.js
│   ├── components/          # Componentes UI
│   ├── lib/                 # Utilidades y configuración
│   └── types/               # Tipos TypeScript
├── prisma/
│   └── schema.prisma        # Esquema de base de datos
├── public/                  # Archivos estáticos
└── README_SETUP.md         # Este archivo
```

## 🌐 Despliegue en Producción

### Vercel (Recomendado)
1. **Sube el código** a GitHub/GitLab
2. **Conecta** tu repositorio con Vercel
3. **Configura** las variables de entorno
4. **Despliega** automáticamente

### Pasos para Vercel:
```bash
# Instalar Vercel CLI
npm i -g vercel

# Desplegar
vercel

# Desplegar en producción
vercel --prod
```

### Configuración de Base de Datos en Producción
```env
# Usar base de datos en la nube
DATABASE_URL="postgresql://usuario:password@host:puerto/database"
```

## 📱 Versión Móvil

### Opción 1: PWA (Progressive Web App)
La aplicación es una PWA y puede instalarse como app nativa:
1. Abre la app en Chrome móvil
2. Toca "Añadir a pantalla de inicio"
3. La app aparecerá en tu escritorio

### Opción 2: App Nativa con Capacitor
```bash
# Instalar Capacitor
npm install @capacitor/core @capacitor/cli
npx cap init SCMApp com.scm.fastdelivery

# Construir para móviles
npm run build
npx cap add android
npx cap add ios
npx cap sync
```

## 🔍 Solución de Problemas

### Problemas Comunes

**Error: "Database connection failed"**
```bash
# Solución: Reconfigurar base de datos
npx prisma db push
```

**Error: "Module not found"**
```bash
# Solución: Reinstalar dependencias
rm -rf node_modules package-lock.json
npm install
```

**Error: "Port 3000 already in use"**
```bash
# Solución: Matar proceso en puerto 3000
npx kill-port 3000
# O usar otro puerto
npm run dev -- -p 3001
```

### Logs y Depuración
```bash
# Ver logs de desarrollo
npm run dev

# Ver logs de errores
npm run lint

# Ver base de datos
npx prisma studio
```

## 📞 Soporte y Ayuda

### Recursos Disponibles
- **Documentación**: Revisa los comentarios en el código
- **API Docs**: `http://localhost:3000/api/docs`
- **Base de Datos**: `npx prisma studio`

### Comandos Útiles
```bash
# Ver todos los comandos disponibles
npm run

# Actualizar dependencias
npm update

# Limpiar caché
npm cache clean --force
```

## 🎯 Próximos Pasos

1. **Explora el panel de administración**
2. **Crea productos de ejemplo**
3. **Registra usuarios de prueba**
4. **Simula pedidos y entregas**
5. **Personaliza la apariencia y funcionalidades**

## 📄 Licencia

Este proyecto es de código abierto y puede utilizarse para fines comerciales y educativos.

---

**¡Listo! Ahora tienes SCM Fast Delivery funcionando en tu entorno local.** 🚀

Para cualquier duda o problema, no dudes en consultar la documentación del código o revisar los logs de la aplicación.