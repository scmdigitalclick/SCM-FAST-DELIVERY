# 📄 Código HTML Completo - SCM Fast Delivery

## 🏗️ Estructura del Proyecto

```
src/
├── app/
│   ├── page.tsx                 # Panel Administrativo Principal
│   ├── customer-platform/
│   │   └── page.tsx            # Plataforma de Clientes
│   ├── delivery-app/
│   │   └── page.tsx            # App de Repartidores
│   └── api/                    # APIs del Backend
│       ├── deliveries/
│       ├── products/
│       ├── categories/
│       ├── branding/
│       └── ...
├── components/
│   ├── ui/                     # Componentes UI (shadcn/ui)
│   ├── DeliveryMap.tsx
│   ├── AddressAutocomplete.tsx
│   └── StoreLocationManager.tsx
└── lib/
    └── db.ts                   # Conexión a Base de Datos
```

---

## 🎨 **HTML del Panel Administrativo Principal**

### **Header Principal**
```html
<header class="bg-white shadow-sm border-b">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="flex items-center justify-between h-16">
      <div class="flex items-center gap-3">
        <div class="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
          <svg class="w-5 h-5 text-white">
            <!-- Package Icon -->
          </svg>
        </div>
        <h1 class="text-xl font-bold text-gray-900">SCM Fast Delivery</h1>
      </div>
    </div>
  </div>
</header>
```

### **Tarjetas de Estadísticas**
```html
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
  <!-- Total Entregas -->
  <div class="bg-white rounded-lg shadow p-4">
    <div class="flex items-center justify-between">
      <div>
        <p class="text-sm text-gray-600">Total Entregas</p>
        <p class="text-2xl font-bold">0</p>
      </div>
      <svg class="w-8 h-8 text-blue-500">
        <!-- Package Icon -->
      </svg>
    </div>
  </div>

  <!-- Pendientes -->
  <div class="bg-white rounded-lg shadow p-4">
    <div class="flex items-center justify-between">
      <div>
        <p class="text-sm text-gray-600">Pendientes</p>
        <p class="text-2xl font-bold text-yellow-600">0</p>
      </div>
      <svg class="w-8 h-8 text-yellow-500">
        <!-- Clock Icon -->
      </svg>
    </div>
  </div>

  <!-- En Progreso -->
  <div class="bg-white rounded-lg shadow p-4">
    <div class="flex items-center justify-between">
      <div>
        <p class="text-sm text-gray-600">En Progreso</p>
        <p class="text-2xl font-bold text-blue-600">0</p>
      </div>
      <svg class="w-8 h-8 text-blue-500">
        <!-- Truck Icon -->
      </svg>
    </div>
  </div>

  <!-- Completadas -->
  <div class="bg-white rounded-lg shadow p-4">
    <div class="flex items-center justify-between">
      <div>
        <p class="text-sm text-gray-600">Completadas</p>
        <p class="text-2xl font-bold text-green-600">0</p>
      </div>
      <svg class="w-8 h-8 text-green-500">
        <!-- CheckCircle Icon -->
      </svg>
    </div>
  </div>

  <!-- Ingresos -->
  <div class="bg-white rounded-lg shadow p-4">
    <div class="flex items-center justify-between">
      <div>
        <p class="text-sm text-gray-600">Ingresos</p>
        <p class="text-2xl font-bold">$0</p>
      </div>
      <svg class="w-8 h-8 text-green-500">
        <!-- TrendingUp Icon -->
      </svg>
    </div>
  </div>
</div>
```

### **Navegación por Pestañas**
```html
<div class="bg-white rounded-lg shadow">
  <div class="border-b border-gray-200">
    <nav class="flex space-x-8 px-4" aria-label="Tabs">
      <button class="py-4 px-1 border-b-2 border-blue-500 font-medium text-sm text-blue-600">
        Entregas
      </button>
      <button class="py-4 px-1 border-b-2 border-transparent font-medium text-sm text-gray-500 hover:text-gray-700 hover:border-gray-300">
        Mapa GPS
      </button>
      <button class="py-4 px-1 border-b-2 border-transparent font-medium text-sm text-gray-500 hover:text-gray-700 hover:border-gray-300">
        Clientes
      </button>
      <button class="py-4 px-1 border-b-2 border-transparent font-medium text-sm text-gray-500 hover:text-gray-700 hover:border-gray-300">
        Locales
      </button>
      <button class="py-4 px-1 border-b-2 border-transparent font-medium text-sm text-gray-500 hover:text-gray-700 hover:border-gray-300">
        Personal
      </button>
      <button class="py-4 px-1 border-b-2 border-transparent font-medium text-sm text-gray-500 hover:text-gray-700 hover:border-gray-300">
        Productos
      </button>
      <button class="py-4 px-1 border-b-2 border-transparent font-medium text-sm text-gray-500 hover:text-gray-700 hover:border-gray-300">
        Branding
      </button>
      <button class="py-4 px-1 border-b-2 border-transparent font-medium text-sm text-gray-500 hover:text-gray-700 hover:border-gray-300">
        Plataformas
      </button>
    </nav>
  </div>
</div>
```

---

## 🛒 **HTML Plataforma de Clientes**

### **Header con Búsqueda y Carrito**
```html
<header class="bg-white shadow-sm border-b">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="flex items-center justify-between h-16">
      <div class="flex items-center gap-3">
        <div class="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
          <svg class="w-5 h-5 text-white">
            <!-- Package Icon -->
          </svg>
        </div>
        <h1 class="text-xl font-bold text-gray-900">SCM Fast Delivery</h1>
      </div>
      
      <div class="flex items-center gap-4">
        <!-- Barra de Búsqueda -->
        <div class="relative">
          <svg class="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4">
            <!-- Search Icon -->
          </svg>
          <input
            type="text"
            placeholder="Buscar productos..."
            class="pl-10 w-64 border border-gray-300 rounded-lg px-3 py-2"
          />
        </div>
        
        <!-- Carrito de Compras -->
        <button class="relative border border-gray-300 rounded-lg px-4 py-2 hover:bg-gray-50">
          <svg class="w-4 h-4 mr-2">
            <!-- ShoppingCart Icon -->
          </svg>
          Carrito
          <span class="absolute -top-2 -right-2 bg-blue-600 text-white rounded-full w-5 h-5 text-xs flex items-center justify-center">
            0
          </span>
        </button>
      </div>
    </div>
  </div>
</header>
```

### **Catálogo de Productos**
```html
<main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
  <!-- Categorías -->
  <div class="mb-8">
    <h2 class="text-2xl font-bold mb-4">Categorías</h2>
    <div class="flex gap-2 flex-wrap">
      <button class="bg-blue-600 text-white px-4 py-2 rounded-lg">
        Todos
      </button>
      <button class="border border-gray-300 px-4 py-2 rounded-lg hover:bg-gray-50">
        Comida (5)
      </button>
      <button class="border border-gray-300 px-4 py-2 rounded-lg hover:bg-gray-50">
        Bebidas (3)
      </button>
      <button class="border border-gray-300 px-4 py-2 rounded-lg hover:bg-gray-50">
        Postres (2)
      </button>
    </div>
  </div>

  <!-- Grid de Productos -->
  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
    <!-- Producto Individual -->
    <div class="bg-white rounded-lg shadow hover:shadow-lg transition-shadow">
      <div class="p-6">
        <!-- Imagen del Producto -->
        <div class="w-full h-48 bg-gray-200 rounded-lg mb-4 flex items-center justify-center">
          <svg class="w-12 h-12 text-gray-400">
            <!-- Package Icon -->
          </svg>
        </div>
        
        <!-- Información del Producto -->
        <h3 class="text-lg font-semibold mb-2">Pizza Grande</h3>
        <p class="text-gray-600 mb-4">Deliciosa pizza con ingredientes frescos</p>
        
        <div class="flex items-center justify-between mb-4">
          <span class="text-2xl font-bold text-blue-600">$15.99</span>
          <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-sm">
            Stock: 10
          </span>
        </div>
        
        <div class="flex items-center gap-2 mb-4">
          <span class="bg-gray-100 px-2 py-1 rounded text-sm">Comida</span>
          <div class="flex items-center gap-1 text-sm text-green-600">
            <svg class="w-3 h-3 text-yellow-500 fill-current">
              <!-- Star Icon -->
            </svg>
            <span>4.5</span>
          </div>
        </div>
        
        <button class="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700">
          <svg class="w-4 h-4 mr-2 inline">
            <!-- ShoppingCart Icon -->
          </svg>
          Agregar al Carrito
        </button>
      </div>
    </div>
  </div>
</main>
```

---

## 📱 **HTML App de Repartidores**

### **Header con Estado de Conexión**
```html
<header class="bg-white shadow-sm border-b">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="flex items-center justify-between h-16">
      <div class="flex items-center gap-3">
        <div class="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center">
          <svg class="w-5 h-5 text-white">
            <!-- Truck Icon -->
          </svg>
        </div>
        <h1 class="text-xl font-bold text-gray-900">SCM Delivery App</h1>
      </div>
      
      <div class="flex items-center gap-4">
        <div class="flex items-center gap-2">
          <div class="w-3 h-3 rounded-full bg-green-500"></div>
          <span class="text-sm font-medium">En línea</span>
        </div>
        
        <button class="bg-blue-600 text-white px-4 py-2 rounded-lg">
          Desconectar
        </button>
      </div>
    </div>
  </div>
</header>
```

### **Tarjeta de Información del Repartidor**
```html
<div class="bg-white rounded-lg shadow p-6 mb-8">
  <div class="flex items-center justify-between">
    <div class="flex items-center gap-4">
      <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
        <svg class="w-8 h-8 text-green-600">
          <!-- User Icon -->
        </svg>
      </div>
      <div>
        <h2 class="text-xl font-bold">Carlos López</h2>
        <p class="text-gray-600 flex items-center gap-1">
          <svg class="w-4 h-4">
            <!-- Phone Icon -->
          </svg>
          +52 123 456 7890
        </p>
        <div class="flex items-center gap-2 mt-1">
          <div class="flex items-center gap-1">
            <svg class="w-4 h-4 text-yellow-500 fill-current">
              <!-- Star Icon -->
            </svg>
            <span class="font-medium">4.8</span>
          </div>
          <span class="text-gray-400">•</span>
          <span class="text-gray-600">156 entregas</span>
        </div>
      </div>
    </div>
    
    <div class="text-right">
      <p class="text-sm text-gray-600">Ganancias Totales</p>
      <p class="text-2xl font-bold text-green-600">$45,680</p>
    </div>
  </div>
</div>
```

### **Lista de Entregas Disponibles**
```html
<div class="space-y-4">
  <!-- Entrega Individual -->
  <div class="bg-white rounded-lg shadow hover:shadow-md transition-shadow">
    <div class="p-6">
      <div class="flex items-center justify-between">
        <div class="flex-1">
          <div class="flex items-center gap-3 mb-3">
            <span class="bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-sm">
              Pendiente
            </span>
            <span class="text-sm text-gray-500">
              10:30 AM
            </span>
          </div>
          
          <h3 class="font-semibold text-lg mb-2">María García</h3>
          <p class="text-gray-600 mb-3 flex items-center gap-2">
            <svg class="w-4 h-4">
              <!-- MapPin Icon -->
            </svg>
            Calle Principal #123, Colonia Centro
          </p>
          
          <div class="flex items-center gap-4 text-sm text-gray-600">
            <span class="flex items-center gap-1">
              <svg class="w-4 h-4">
                <!-- Package Icon -->
              </svg>
              3 artículos
            </span>
            <span class="flex items-center gap-1">
              <svg class="w-4 h-4">
                <!-- DollarSign Icon -->
              </svg>
              $45.99
            </span>
            <span class="flex items-center gap-1">
              <svg class="w-4 h-4">
                <!-- Clock Icon -->
              </svg>
              30 min
            </span>
            <span class="flex items-center gap-1">
              <svg class="w-4 h-4">
                <!-- Navigation Icon -->
              </svg>
              2.5 km
            </span>
          </div>
          
          <p class="text-sm text-gray-500 mt-2">
            Desde: Tienda Central
          </p>
        </div>
        
        <div class="flex flex-col gap-2">
          <button class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 whitespace-nowrap">
            <svg class="w-4 h-4 mr-2 inline">
              <!-- Truck Icon -->
            </svg>
            Aceptar
          </button>
          <button class="border border-gray-300 px-3 py-1 rounded text-sm hover:bg-gray-50">
            <svg class="w-4 h-4 mr-1 inline">
              <!-- Navigation Icon -->
            </svg>
            Ver Ruta
          </button>
        </div>
      </div>
    </div>
  </div>
</div>
```

---

## 🎨 **Componentes UI (shadcn/ui)**

### **Botones**
```html
<!-- Botón Primario -->
<button class="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-blue-600 text-white hover:bg-blue-700 h-10 px-4 py-2">
  <svg class="w-4 h-4 mr-2">
    <!-- Icon -->
  </svg>
  Button Text
</button>

<!-- Botón Secundario -->
<button class="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-gray-300 bg-white hover:bg-gray-50 h-10 px-4 py-2">
  Button Text
</button>
```

### **Tarjetas (Cards)**
```html
<div class="rounded-lg border bg-card text-card-foreground shadow-sm">
  <div class="flex flex-col space-y-1.5 p-6">
    <h3 class="text-2xl font-semibold leading-none tracking-tight">
      Card Title
    </h3>
    <p class="text-sm text-muted-foreground">
      Card Description
    </p>
  </div>
  <div class="p-6 pt-0">
    Card Content
  </div>
</div>
```

### **Inputs**
```html
<div class="grid w-full max-w-sm items-center gap-1.5">
  <label class="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
    Label
  </label>
  <input class="flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-gray-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50" type="text" placeholder="Placeholder">
</div>
```

---

## 📊 **APIs Endpoints**

### **Endpoints Disponibles**
```
GET  /api/deliveries          # Obtener entregas
POST /api/deliveries          # Crear entrega
PUT  /api/deliveries/:id      # Actualizar entrega

GET  /api/products            # Obtener productos
POST /api/products            # Crear producto

GET  /api/categories          # Obtener categorías
POST /api/categories          # Crear categoría

GET  /api/customers           # Obtener clientes
POST /api/customers           # Crear cliente

GET  /api/delivery-persons    # Obtener repartidores
POST /api/delivery-persons    # Crear repartidor

GET  /api/store-locations     # Obtener locales
POST /api/store-locations     # Crear local

GET  /api/branding            # Obtener branding
PUT  /api/branding            # Actualizar branding

GET  /api/stats               # Obtener estadísticas
```

---

## 🎯 **Estructura de Datos**

### **Delivery**
```typescript
interface Delivery {
  id: string
  customerName: string
  customerAddress: string
  customerLat?: number
  customerLng?: number
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED'
  items: number
  total: number
  estimatedTime: string
  distance?: number
  notes?: string
  createdAt: string
  storeLocation?: StoreLocation
}
```

### **Product**
```typescript
interface Product {
  id: string
  name: string
  description?: string
  price: number
  imageUrl?: string
  sku?: string
  stock: number
  isActive: boolean
  category: Category
}
```

---

## 🚀 **Cómo Ver el HTML en el Navegador**

### **Opción 1: Desarrollo Local**
```bash
npm run dev
# Abre http://localhost:3000
```

### **Opción 2: Producción (Vercel)**
```bash
npm run build
npm start
# O despliega en Vercel
```

### **Opción 3: Ver HTML Compilado**
```bash
npm run build
# El HTML compilado está en:
# .next/server/app/page.html
```

---

## 📱 **Versión Móvil (Responsive)**

El código incluye clases responsive de Tailwind CSS:

- **sm**: small (640px+)
- **md**: medium (768px+)
- **lg**: large (1024px+)
- **xl**: extra-large (1280px+)

Ejemplos:
```html
<!-- Grid responsive -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">

<!-- Padding responsive -->
<div class="p-4 md:p-6 lg:p-8">

<!-- Texto responsive -->
<h1 class="text-2xl md:text-3xl lg:text-4xl">
```

---

## 🎨 **Estilos CSS (Tailwind)**

### **Colores Principales**
```css
/* Primarios */
.bg-blue-600    /* Azul principal */
.text-blue-600  /* Texto azul */

/* Secundarios */
.bg-gray-50     /* Fondo gris claro */
.text-gray-900  /* Texto negro */

/* Estados */
.bg-green-100   /* Success */
.bg-yellow-100  /* Warning */
.bg-red-100     /* Error */
```

### **Sombras y Bordes**
```css
.shadow-sm      /* Sombra pequeña */
.shadow-lg      /* Sombra grande */
.border         /* Borde gris */
.rounded-lg     /* Bordes redondeados */
```

---

## 🔧 **Personalización del HTML**

### **Cambiar Colores**
```typescript
// En tailwind.config.ts
theme: {
  extend: {
    colors: {
      primary: '#0ea5e9',    // Azul personalizado
      secondary: '#64748b',  // Gris personalizado
      accent: '#10b981'      // Verde personalizado
    }
  }
}
```

### **Cambiar Tipografía**
```html
<h1 class="font-bold text-gray-900" style="font-family: 'TuFont', sans-serif;">
  SCM Fast Delivery
</h1>
```

---

## 📄 **HTML Completo Compilado**

Para ver el HTML completo compilado:

1. **Ejecuta el build:**
   ```bash
   npm run build
   ```

2. **Revisa los archivos generados:**
   ```
   .next/
   ├── server/app/
   │   ├── page.html          # HTML del panel admin
   │   ├── customer-platform/
   │   │   └── page.html      # HTML de clientes
   │   └── delivery-app/
   │       └── page.html      # HTML de repartidores
   └── static/                # CSS y JS compilados
   ```

3. **Abre el HTML en tu navegador:**
   ```bash
   # Si tienes Python
   python -m http.server 8000
   
   # O usa Node.js
   npx serve .next/server/app
   ```

---

## 🎯 **Resumen del Código HTML**

Tu aplicación SCM Fast Delivery incluye:

✅ **3 Plataformas Completas** con HTML responsive  
✅ **Componentes UI Modernos** con shadcn/ui  
✅ **Diseño Mobile-First** con Tailwind CSS  
✅ **APIs REST** para toda la funcionalidad  
✅ **Base de Datos** con Prisma ORM  
✅ **GPS y Mapas** integrados  
✅ **Sistema de Pagos** simulado  
✅ **Notificaciones** en tiempo real  

**¿Quieres ver alguna sección específica del HTML? ¿O necesitas el código compilado de alguna plataforma en particular?** 🚀