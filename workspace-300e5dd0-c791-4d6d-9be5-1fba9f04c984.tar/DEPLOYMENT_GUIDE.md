# 🌐 Guía de Despliegue - SCM Fast Delivery

## Despliegue en Producción

### 🚀 Opción 1: Vercel (Recomendado)

#### Paso 1: Preparar el Repositorio
```bash
# Inicializar Git si no está hecho
git init
git add .
git commit -m "Initial commit - SCM Fast Delivery"

# Subir a GitHub
git branch -M main
git remote add origin https://github.com/tu-usuario/scm-fast-delivery.git
git push -u origin main
```

#### Paso 2: Configurar Vercel
1. **Ve a [vercel.com](https://vercel.com)**
2. **Inicia sesión con tu cuenta GitHub**
3. **Haz clic en "New Project"**
4. **Selecciona tu repositorio scm-fast-delivery**
5. **Configura las variables de entorno**:

```env
DATABASE_URL="postgresql://usuario:password@host:puerto/database"
NEXTAUTH_URL="https://tu-dominio.vercel.app"
NEXTAUTH_SECRET="tu-secreto-muy-seguro-aqui"
```

#### Paso 3: Despliegue Automático
- **Vercel detectará automáticamente que es Next.js**
- **Construirá y desplegará tu aplicación**
- **Te dará una URL temporal**: `https://tu-proyecto.vercel.app`

### 🐳 Opción 2: Docker

#### Crear Dockerfile
```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npx prisma generate
RUN npm run build

EXPOSE 3000

CMD ["npm", "start"]
```

#### Crear docker-compose.yml
```yaml
version: '3.8'
services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - DATABASE_URL=postgresql://postgres:password@db:5432/scm
      - NEXTAUTH_URL=http://localhost:3000
      - NEXTAUTH_SECRET=tu-secreto-aqui
    depends_on:
      - db

  db:
    image: postgres:14
    environment:
      - POSTGRES_DB=scm
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  postgres_data:
```

#### Ejecutar Docker
```bash
# Construir y ejecutar
docker-compose up -d

# Ver logs
docker-compose logs -f

# Detener
docker-compose down
```

### ☁️ Opción 3: Railway

#### Paso 1: Preparar Railway
1. **Crea cuenta en [railway.app](https://railway.app)**
2. **Conecta tu repositorio GitHub**
3. **Selecciona el repositorio scm-fast-delivery**

#### Paso 2: Configurar Variables
```env
NODE_ENV=production
DATABASE_URL=${{RAILWAY_DATABASE_URL}}
NEXTAUTH_URL=${{RAILWAY_PUBLIC_DOMAIN}}
NEXTAUTH_SECRET=tu-secreto-aqui
```

#### Paso 3: Despliegue
- **Railway construirá automáticamente**
- **Te dará una URL pública**
- **Base de datos PostgreSQL incluida**

### 🔧 Opción 4: Servidor Propio (VPS)

#### Requisitos del Servidor
- **Ubuntu 20.04+ o CentOS 8+**
- **Node.js 18+**
- **Nginx (opcional, para proxy inverso)**
- **PostgreSQL o MySQL**

#### Instalación en VPS
```bash
# Actualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Instalar PM2 para gestión de procesos
sudo npm install -g pm2

# Clonar proyecto
git clone [URL-del-repositorio]
cd scm-fast-delivery

# Instalar dependencias
npm install

# Configurar variables de entorno
cp .env.example .env
# Editar .env con tus datos

# Construir aplicación
npm run build

# Iniciar con PM2
pm2 start npm --name "scm-delivery" -- start
pm2 save
pm2 startup
```

#### Configurar Nginx (Opcional)
```nginx
# /etc/nginx/sites-available/scm-delivery
server {
    listen 80;
    server_name tu-dominio.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# Activar sitio
sudo ln -s /etc/nginx/sites-available/scm-delivery /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

## 📱 Configuración de Base de Datos en Producción

### PostgreSQL (Recomendado)
```env
DATABASE_URL="postgresql://username:password@host:port/database"
```

### PlanetScale (MySQL Serverless)
```env
DATABASE_URL="mysql://username:password@host:port/database?sslaccept=strict"
```

### Supabase (PostgreSQL Serverless)
```env
DATABASE_URL="postgresql://postgres:[PASSWORD]@db.[PROJECT_ID].supabase.co:5432/postgres"
```

## 🔐 Configuración SSL y HTTPS

### Certbot con Let's Encrypt
```bash
# Instalar Certbot
sudo apt install certbot python3-certbot-nginx

# Obtener certificado
sudo certbot --nginx -d tu-dominio.com

# Renovación automática
sudo crontab -e
# Agregar: 0 12 * * * /usr/bin/certbot renew --quiet
```

## 📊 Monitoreo y Logs

### PM2 Monitoring
```bash
# Ver procesos
pm2 list

# Ver logs
pm2 logs scm-delivery

# Monitoreo en tiempo real
pm2 monit

# Reiniciar aplicación
pm2 restart scm-delivery
```

### Health Check Endpoint
```javascript
// Agregar a src/app/api/health/route.ts
export async function GET() {
  return Response.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
}
```

## 🔄 Actualizaciones y Mantenimiento

### Script de Actualización Automática
```bash
#!/bin/bash
# update.sh
cd /path/to/scm-fast-delivery
git pull origin main
npm install
npm run build
pm2 restart scm-delivery
echo "Actualización completada: $(date)"
```

### Cron Job para Actualizaciones
```bash
# Editar crontab
crontab -e

# Actualizar cada día a las 2 AM
0 2 * * * /path/to/update.sh >> /var/log/scm-updates.log 2>&1
```

## 🚨 Backup y Recuperación

### Backup de Base de Datos
```bash
# PostgreSQL
pg_dump -h host -U username database > backup.sql

# Restaurar
psql -h host -U username database < backup.sql
```

### Backup Automático
```bash
#!/bin/bash
# backup.sh
DATE=$(date +%Y%m%d_%H%M%S)
pg_dump -h $DB_HOST -U $DB_USER $DB_NAME > /backups/scm_backup_$DATE.sql
find /backups -name "scm_backup_*.sql" -mtime +7 -delete
```

## 📈 Optimización de Rendimiento

### Next.js Configuración de Producción
```javascript
// next.config.js
module.exports = {
  compress: true,
  poweredByHeader: false,
  reactStrictMode: true,
  swcMinify: true,
  
  // Optimización de imágenes
  images: {
    domains: ['tu-dominio.com'],
    formats: ['image/webp', 'image/avif'],
  },
  
  // Configuración de producción
  env: {
    CUSTOM_KEY: process.env.CUSTOM_KEY,
  },
}
```

### Caching con Redis (Opcional)
```javascript
// lib/redis.ts
import Redis from 'ioredis';

const redis = new Redis(process.env.REDIS_URL);

export async function cacheData(key: string, data: any, ttl = 3600) {
  await redis.setex(key, ttl, JSON.stringify(data));
}

export async function getCachedData(key: string) {
  const data = await redis.get(key);
  return data ? JSON.parse(data) : null;
}
```

## 🎯 Checklist de Despliegue

### Antes del Despliegue
- [ ] Probar en entorno de desarrollo
- [ ] Revisar variables de entorno
- [ ] Optimizar imágenes y assets
- [ ] Configurar base de datos de producción
- [ ] Establecer dominio y SSL

### Después del Despliegue
- [ ] Verificar funcionalidad básica
- [ ] Probar registro y login
- [ ] Realizar pedido de prueba
- [ ] Configurar monitoreo
- [ ] Establecer backups automáticos
- [ ] Documentar acceso administrativo

---

**¡Tu SCM Fast Delivery está listo para producción!** 🚀

Para soporte adicional, consulta la documentación del proyecto o contacta al equipo de desarrollo.