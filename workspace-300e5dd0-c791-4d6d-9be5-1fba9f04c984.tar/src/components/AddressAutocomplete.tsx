'use client'

import { useState, useEffect, useRef } from 'react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { MapPin, Loader2, Crosshair, Navigation } from 'lucide-react'

interface AddressSuggestion {
  display_name: string
  lat: string
  lon: string
  importance: number
}

interface AddressAutocompleteProps {
  value: string
  onChange: (address: string, coordinates?: { lat: number; lng: number }) => void
  placeholder?: string
  className?: string
  disabled?: boolean
}

export default function AddressAutocomplete({
  value,
  onChange,
  placeholder = "Ingresa la dirección...",
  className = "",
  disabled = false
}: AddressAutocompleteProps) {
  const [suggestions, setSuggestions] = useState<AddressSuggestion[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [isGettingLocation, setIsGettingLocation] = useState(false)
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number } | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const debounceRef = useRef<NodeJS.Timeout>()

  // Obtener ubicación actual del usuario
  const getCurrentLocation = async () => {
    if (!navigator.geolocation) {
      alert('Tu navegador no soporta geolocalización')
      return
    }

    setIsGettingLocation(true)
    try {
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 300000 // 5 minutos
        })
      })

      const { latitude, longitude } = position.coords
      setCurrentLocation({ lat: latitude, lng: longitude })

      // Obtener dirección desde coordenadas (reverse geocoding)
      const response = await fetch(
        `/api/geocode?lat=${latitude}&lng=${longitude}`
      )
      
      if (response.ok) {
        const data = await response.json()
        onChange(data.address, { lat: latitude, lng: longitude })
      }
    } catch (error) {
      console.error('Error obteniendo ubicación:', error)
      alert('No se pudo obtener tu ubicación actual')
    } finally {
      setIsGettingLocation(false)
    }
  }

  // Buscar sugerencias de direcciones
  const searchAddresses = async (query: string) => {
    if (query.length < 3) {
      setSuggestions([])
      return
    }

    setIsLoading(true)
    try {
      const response = await fetch('/api/geocode', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ address: query }),
      })

      if (response.ok) {
        const data = await response.json()
        // Para obtener múltiples sugerencias, hacemos otra llamada
        const suggestionsResponse = await fetch(
          `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=json&limit=5&countrycodes=mx`,
          {
            headers: {
              'User-Agent': 'SCM Fast Delivery (contact@scmfastdelivery.com)'
            }
          }
        )
        
        if (suggestionsResponse.ok) {
          const suggestionsData = await suggestionsResponse.json()
          setSuggestions(suggestionsData)
        }
      }
    } catch (error) {
      console.error('Error buscando direcciones:', error)
    } finally {
      setIsLoading(false)
    }
  }

  // Manejar cambios en el input con debounce
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    onChange(value) // Actualizar el valor del input
    
    // Limpiar debounce anterior
    if (debounceRef.current) {
      clearTimeout(debounceRef.current)
    }

    // Configurar nuevo debounce
    debounceRef.current = setTimeout(() => {
      searchAddresses(value)
    }, 300)

    setShowSuggestions(true)
  }

  // Seleccionar una sugerencia
  const selectSuggestion = (suggestion: AddressSuggestion) => {
    onChange(suggestion.display_name, {
      lat: parseFloat(suggestion.lat),
      lng: parseFloat(suggestion.lon)
    })
    setShowSuggestions(false)
    setSuggestions([])
  }

  // Cerrar sugerencias al hacer clic fuera
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (inputRef.current && !inputRef.current.contains(event.target as Node)) {
        setShowSuggestions(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
      if (debounceRef.current) {
        clearTimeout(debounceRef.current)
      }
    }
  }, [])

  return (
    <div className="relative">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Input
            ref={inputRef}
            value={value}
            onChange={handleInputChange}
            placeholder={placeholder}
            className={className}
            disabled={disabled || isLoading}
            onFocus={() => setShowSuggestions(true)}
          />
          
          {isLoading && (
            <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
              <Loader2 className="w-4 h-4 animate-spin text-gray-400" />
            </div>
          )}
        </div>
        
        <Button
          type="button"
          variant="outline"
          size="icon"
          onClick={getCurrentLocation}
          disabled={isGettingLocation || disabled}
          title="Usar mi ubicación actual"
        >
          {isGettingLocation ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Crosshair className="w-4 h-4" />
          )}
        </Button>
      </div>

      {/* Sugerencias de direcciones */}
      {showSuggestions && suggestions.length > 0 && (
        <Card className="absolute z-50 w-full mt-1 max-h-60 overflow-y-auto">
          <CardContent className="p-0">
            {suggestions.map((suggestion, index) => (
              <button
                key={index}
                className="w-full text-left px-3 py-2 hover:bg-gray-100 border-b last:border-b-0 transition-colors"
                onClick={() => selectSuggestion(suggestion)}
              >
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-900 truncate">
                      {suggestion.display_name}
                    </p>
                  </div>
                </div>
              </button>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Indicador de ubicación actual */}
      {currentLocation && (
        <div className="mt-2">
          <Badge variant="secondary" className="text-xs">
            <Navigation className="w-3 h-3 mr-1" />
            Ubicación actual detectada
          </Badge>
        </div>
      )}
    </div>
  )
}