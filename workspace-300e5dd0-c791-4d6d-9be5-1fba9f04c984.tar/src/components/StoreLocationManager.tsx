'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Store, MapPin, Edit, Trash2, Plus, Navigation } from 'lucide-react'
import AddressAutocomplete from './AddressAutocomplete'

interface StoreLocation {
  id: string
  name: string
  address: string
  latitude: number
  longitude: number
  phone?: string
  email?: string
  isActive: boolean
  createdAt: string
  updatedAt: string
}

interface StoreLocationManagerProps {
  onStoreSelect?: (store: StoreLocation) => void
  selectedStoreId?: string
}

export default function StoreLocationManager({ 
  onStoreSelect, 
  selectedStoreId 
}: StoreLocationManagerProps) {
  const [stores, setStores] = useState<StoreLocation[]>([])
  const [loading, setLoading] = useState(true)
  const [dialogOpen, setDialogOpen] = useState(false)
  const [editingStore, setEditingStore] = useState<StoreLocation | null>(null)
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    latitude: 0,
    longitude: 0,
    phone: '',
    email: '',
    isActive: true
  })

  useEffect(() => {
    fetchStores()
  }, [])

  const fetchStores = async () => {
    try {
      const response = await fetch('/api/store-locations')
      if (response.ok) {
        const data = await response.json()
        setStores(data)
      }
    } catch (error) {
      console.error('Error fetching stores:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      const url = editingStore 
        ? `/api/store-locations/${editingStore.id}`
        : '/api/store-locations'
      
      const method = editingStore ? 'PUT' : 'POST'
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        setDialogOpen(false)
        resetForm()
        fetchStores()
      }
    } catch (error) {
      console.error('Error saving store:', error)
    }
  }

  const handleDelete = async (id: string) => {
    if (!confirm('¿Estás seguro de eliminar esta local?')) return
    
    try {
      const response = await fetch(`/api/store-locations/${id}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        fetchStores()
      }
    } catch (error) {
      console.error('Error deleting store:', error)
    }
  }

  const handleEdit = (store: StoreLocation) => {
    setEditingStore(store)
    setFormData({
      name: store.name,
      address: store.address,
      latitude: store.latitude,
      longitude: store.longitude,
      phone: store.phone || '',
      email: store.email || '',
      isActive: store.isActive
    })
    setDialogOpen(true)
  }

  const resetForm = () => {
    setEditingStore(null)
    setFormData({
      name: '',
      address: '',
      latitude: 0,
      longitude: 0,
      phone: '',
      email: '',
      isActive: true
    })
  }

  const handleAddressChange = (address: string, coordinates?: { lat: number; lng: number }) => {
    setFormData(prev => ({
      ...prev,
      address,
      latitude: coordinates?.lat || 0,
      longitude: coordinates?.lng || 0
    }))
  }

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Store className="w-5 h-5" />
            Locales SCM
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-4">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600 mx-auto"></div>
            <p className="text-sm text-gray-600 mt-2">Cargando locales...</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Store className="w-5 h-5" />
              Locales SCM Fast Delivery
            </CardTitle>
            <CardDescription>
              Gestiona tus locales de origen para entregas
            </CardDescription>
          </div>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={resetForm}>
                <Plus className="w-4 h-4 mr-2" />
                Nuevo Local
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>
                  {editingStore ? 'Editar Local' : 'Agregar Nuevo Local'}
                </DialogTitle>
                <DialogDescription>
                  Configura un nuevo local para SCM Fast Delivery
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Nombre del Local</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Ej: SCM Central"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Teléfono</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                      placeholder="+52 123 456 7890"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="address">Dirección del Local</Label>
                  <AddressAutocomplete
                    value={formData.address}
                    onChange={handleAddressChange}
                    placeholder="Ingresa la dirección del local..."
                  />
                </div>

                <div>
                  <Label htmlFor="email">Email (Opcional)</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    placeholder="local@scmfastdelivery.com"
                  />
                </div>

                {formData.latitude !== 0 && formData.longitude !== 0 && (
                  <div className="bg-blue-50 p-3 rounded-lg">
                    <div className="flex items-center gap-2 text-sm text-blue-800">
                      <Navigation className="w-4 h-4" />
                      <span>
                        Coordenadas: {formData.latitude.toFixed(6)}, {formData.longitude.toFixed(6)}
                      </span>
                    </div>
                  </div>
                )}

                <div className="flex justify-end gap-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setDialogOpen(false)}
                  >
                    Cancelar
                  </Button>
                  <Button type="submit">
                    {editingStore ? 'Actualizar' : 'Crear'} Local
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {stores.length === 0 ? (
            <div className="text-center py-8">
              <Store className="w-12 h-12 mx-auto text-gray-400 mb-4" />
              <p className="text-gray-600">No hay locales configurados</p>
              <p className="text-sm text-gray-500 mt-1">
                Agrega tu primer local para comenzar a gestionar entregas
              </p>
            </div>
          ) : (
            stores.map((store) => (
              <div
                key={store.id}
                className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                  selectedStoreId === store.id 
                    ? 'border-blue-500 bg-blue-50' 
                    : 'border-gray-200 hover:border-gray-300'
                }`}
                onClick={() => onStoreSelect?.(store)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="font-semibold">{store.name}</h4>
                      <Badge className={store.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                        {store.isActive ? 'Activo' : 'Inactivo'}
                      </Badge>
                    </div>
                    <div className="space-y-1 text-sm text-gray-600">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4" />
                        <span>{store.address}</span>
                      </div>
                      {store.phone && (
                        <p>Tel: {store.phone}</p>
                      )}
                      {store.email && (
                        <p>Email: {store.email}</p>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-1 ml-4">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={(e) => {
                        e.stopPropagation()
                        handleEdit(store)
                      }}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={(e) => {
                        e.stopPropagation()
                        handleDelete(store.id)
                      }}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  )
}