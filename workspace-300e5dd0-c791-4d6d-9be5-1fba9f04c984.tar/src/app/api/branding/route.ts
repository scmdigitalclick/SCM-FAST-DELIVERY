import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    let branding = await db.branding.findFirst();
    
    if (!branding) {
      branding = await db.branding.create({
        data: {
          companyName: 'SCM Fast Delivery',
          primaryColor: '#000000',
          secondaryColor: '#ffffff',
          accentColor: '#3b82f6'
        }
      });
    }

    return NextResponse.json(branding);
  } catch (error) {
    console.error('Error fetching branding:', error);
    return NextResponse.json(
      { error: 'Error fetching branding' },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { 
      companyName, 
      logoUrl, 
      primaryColor, 
      secondaryColor, 
      accentColor, 
      slogan, 
      description, 
      website, 
      socialMedia, 
      contactInfo 
    } = body;

    let branding = await db.branding.findFirst();

    if (!branding) {
      branding = await db.branding.create({
        data: {
          companyName,
          logoUrl,
          primaryColor,
          secondaryColor,
          accentColor,
          slogan,
          description,
          website,
          socialMedia,
          contactInfo
        }
      });
    } else {
      branding = await db.branding.update({
        where: { id: branding.id },
        data: {
          companyName,
          logoUrl,
          primaryColor,
          secondaryColor,
          accentColor,
          slogan,
          description,
          website,
          socialMedia,
          contactInfo
        }
      });
    }

    return NextResponse.json(branding);
  } catch (error) {
    console.error('Error updating branding:', error);
    return NextResponse.json(
      { error: 'Error updating branding' },
      { status: 500 }
    );
  }
}