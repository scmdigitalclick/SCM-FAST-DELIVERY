import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const store = await db.storeLocation.findUnique({
      where: { id: params.id }
    })

    if (!store) {
      return NextResponse.json(
        { error: 'Store location not found' },
        { status: 404 }
      )
    }

    return NextResponse.json(store)
  } catch (error) {
    console.error('Error fetching store location:', error)
    return NextResponse.json(
      { error: 'Error fetching store location' },
      { status: 500 }
    )
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const {
      name,
      address,
      latitude,
      longitude,
      phone,
      email,
      isActive
    } = body

    const store = await db.storeLocation.update({
      where: { id: params.id },
      data: {
        name,
        address,
        latitude,
        longitude,
        phone,
        email,
        isActive
      }
    })

    return NextResponse.json(store)
  } catch (error) {
    console.error('Error updating store location:', error)
    return NextResponse.json(
      { error: 'Error updating store location' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await db.storeLocation.delete({
      where: { id: params.id }
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting store location:', error)
    return NextResponse.json(
      { error: 'Error deleting store location' },
      { status: 500 }
    )
  }
}