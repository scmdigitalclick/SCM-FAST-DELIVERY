import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const stores = await db.storeLocation.findMany({
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json(stores)
  } catch (error) {
    console.error('Error fetching store locations:', error)
    return NextResponse.json(
      { error: 'Error fetching store locations' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      name,
      address,
      latitude,
      longitude,
      phone,
      email,
      isActive = true
    } = body

    if (!name || !address || latitude === 0 || longitude === 0) {
      return NextResponse.json(
        { error: 'Nombre, dirección y coordenadas son requeridas' },
        { status: 400 }
      )
    }

    const store = await db.storeLocation.create({
      data: {
        name,
        address,
        latitude,
        longitude,
        phone,
        email,
        isActive
      }
    })

    return NextResponse.json(store, { status: 201 })
  } catch (error) {
    console.error('Error creating store location:', error)
    return NextResponse.json(
      { error: 'Error creating store location' },
      { status: 500 }
    )
  }
}