import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const [
      totalDeliveries,
      pendingDeliveries,
      inProgressDeliveries,
      completedDeliveries,
      totalRevenue
    ] = await Promise.all([
      db.delivery.count(),
      db.delivery.count({ where: { status: 'PENDING' } }),
      db.delivery.count({ where: { status: 'IN_PROGRESS' } }),
      db.delivery.count({ where: { status: 'COMPLETED' } }),
      db.delivery.aggregate({
        where: { status: 'COMPLETED' },
        _sum: { total: true }
      })
    ])

    const stats = {
      totalDeliveries,
      pendingDeliveries,
      inProgressDeliveries,
      completedDeliveries,
      totalRevenue: totalRevenue._sum.total || 0
    }

    return NextResponse.json(stats)
  } catch (error) {
    console.error('Error fetching stats:', error)
    return NextResponse.json(
      { error: 'Error fetching stats' },
      { status: 500 }
    )
  }
}