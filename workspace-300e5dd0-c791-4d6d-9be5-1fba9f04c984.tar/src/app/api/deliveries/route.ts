import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const deliveries = await db.delivery.findMany({
      include: {
        customer: true,
        deliveryPerson: true
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json(deliveries)
  } catch (error) {
    console.error('Error fetching deliveries:', error)
    return NextResponse.json(
      { error: 'Error fetching deliveries' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      customerName,
      customerAddress,
      customerId,
      items,
      total,
      estimatedTime,
      notes
    } = body

    const delivery = await db.delivery.create({
      data: {
        customerName,
        customerAddress,
        customerId,
        items,
        total,
        estimatedTime,
        notes,
        status: 'PENDING'
      },
      include: {
        customer: true,
        deliveryPerson: true
      }
    })

    return NextResponse.json(delivery, { status: 201 })
  } catch (error) {
    console.error('Error creating delivery:', error)
    return NextResponse.json(
      { error: 'Error creating delivery' },
      { status: 500 }
    )
  }
}