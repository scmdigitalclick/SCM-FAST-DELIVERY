import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const deliveryPersons = await db.deliveryPerson.findMany({
      where: {
        isAvailable: true
      },
      include: {
        deliveries: {
          where: {
            status: {
              in: ['PENDING', 'IN_PROGRESS']
            }
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    const deliveryPersonsWithStats = deliveryPersons.map(person => ({
      ...person,
      activeDeliveries: person.deliveries.length
    }))

    return NextResponse.json(deliveryPersonsWithStats)
  } catch (error) {
    console.error('Error fetching delivery persons:', error)
    return NextResponse.json(
      { error: 'Error fetching delivery persons' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, email, phone } = body

    const deliveryPerson = await db.deliveryPerson.create({
      data: {
        name,
        email,
        phone,
        isAvailable: true
      }
    })

    return NextResponse.json(deliveryPerson, { status: 201 })
  } catch (error) {
    console.error('Error creating delivery person:', error)
    return NextResponse.json(
      { error: 'Error creating delivery person' },
      { status: 500 }
    )
  }
}