'use client'

import { useState, useEffect, useCallback } from 'react'

interface Location {
  lat: number
  lng: number
}

interface DeliveryPersonLocation {
  id: string
  name: string
  phone: string
  isAvailable: boolean
  activeDeliveries: number
  location: Location
}

interface DeliveryLocation {
  id: string
  customerName: string
  customerAddress: string
  status: 'PENDING' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED'
  deliveryPerson?: {
    name: string
    phone: string
  }
  estimatedTime: string
  items: number
  total: number
  location: Location
}

export function useRealTimeLocations() {
  const [deliveryPersons, setDeliveryPersons] = useState<DeliveryPersonLocation[]>([])
  const [deliveries, setDeliveries] = useState<DeliveryLocation[]>([])
  const [isConnected, setIsConnected] = useState(false)

  // Simular actualización de ubicaciones en tiempo real
  const simulateLocationUpdate = useCallback(() => {
    // Actualizar ubicaciones de repartidores
    setDeliveryPersons(prev => prev.map(person => ({
      ...person,
      location: {
        lat: person.location.lat + (Math.random() - 0.5) * 0.001,
        lng: person.location.lng + (Math.random() - 0.5) * 0.001
      }
    })))

    // Actualizar ubicaciones de entregas en progreso
    setDeliveries(prev => prev.map(delivery => {
      if (delivery.status === 'IN_PROGRESS') {
        return {
          ...delivery,
          location: {
            lat: delivery.location.lat + (Math.random() - 0.5) * 0.0005,
            lng: delivery.location.lng + (Math.random() - 0.5) * 0.0005
          }
        }
      }
      return delivery
    }))
  }, [])

  useEffect(() => {
    // Simular conexión WebSocket
    setIsConnected(true)

    // Actualizar ubicaciones cada 5 segundos
    const interval = setInterval(simulateLocationUpdate, 5000)

    return () => {
      clearInterval(interval)
      setIsConnected(false)
    }
  }, [simulateLocationUpdate])

  const updateDeliveryPersons = useCallback((persons: any[]) => {
    const baseLocations = [
      { lat: 19.4326, lng: -99.1332 }, // Centro
      { lat: 19.4400, lng: -99.1400 }, // Norte
      { lat: 19.4200, lng: -99.1500 }, // Sur
      { lat: 19.4500, lng: -99.1200 }, // Este
      { lat: 19.4100, lng: -99.1600 }, // Oeste
    ]

    const personsWithLocation = persons.map((person, index) => ({
      ...person,
      location: baseLocations[index % baseLocations.length]
    }))

    setDeliveryPersons(personsWithLocation)
  }, [])

  const updateDeliveries = useCallback((deliveryList: any[]) => {
    const baseLocations = [
      { lat: 19.4326, lng: -99.1332 }, // Centro
      { lat: 19.4400, lng: -99.1400 }, // Norte
      { lat: 19.4200, lng: -99.1500 }, // Sur
      { lat: 19.4500, lng: -99.1200 }, // Este
      { lat: 19.4100, lng: -99.1600 }, // Oeste
    ]

    const deliveriesWithLocation = deliveryList.map((delivery, index) => ({
      ...delivery,
      location: {
        lat: baseLocations[index % baseLocations.length].lat + (Math.random() - 0.5) * 0.02,
        lng: baseLocations[index % baseLocations.length].lng + (Math.random() - 0.5) * 0.02
      }
    }))

    setDeliveries(deliveriesWithLocation)
  }, [])

  return {
    deliveryPersons,
    deliveries,
    isConnected,
    updateDeliveryPersons,
    updateDeliveries
  }
}